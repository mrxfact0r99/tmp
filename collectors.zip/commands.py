"""
commands.py - Command history evidence collector.

UPGRADE NOTES ("deleted commands"):
Shell history files (`.bash_history`, `.zsh_history`, ...) are plain
append-only text files with no undelete mechanism of their own, so once a
line is truly gone (file cleared / `history -c` and no auto-save yet), the
file itself holds nothing to recover. To still surface "commands that
aren't in the history file", this version adds:

  1. Tamper heuristics: flags a history file that is suspiciously small,
     empty, or was truncated/modified right after the account's last login
     -- a classic `history -c` / `> ~/.bash_history` signature.
  2. Cross-source correlation: auditd (`type=EXECVE`) logs command
     execution independently of the shell's own history file, so a
     cleared `.bash_history` can often still be reconstructed from auditd
     if it was running. This module now pulls EXECVE records directly
     (previously only the executed-programs module touched auditd) and
     cross-references counts against what each shell history file reports,
     surfacing the gap explicitly.
  3. Windows: adds UserAssist registry decoding (ROT13-obfuscated GUI
     program execution history -- survives independently of any command
     history / Doskey buffer, which Windows does not persist at all) and
     notes that clarify what actually can/can't be recovered on Windows.

Honesty note: none of this "un-deletes" bytes that were never logged
anywhere. It maximizes cross-referencing of independent logging sources so
a cleared history file is not the end of the trail.
"""

import os
import re
import sys
import json
import platform
from pathlib import Path
from datetime import datetime, timedelta

try:
    from ..common import (
        EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence,
        append_manifest_entry, get_logger, run_command, stat_times,
    )
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import (
        EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence,
        append_manifest_entry, get_logger, run_command, stat_times,
    )

try:
    import winreg
except ImportError:
    winreg = None

MODULE_NAME = "command_history"


def filetime_to_datetime(ft):
    if not ft or ft <= 0:
        return None
    try:
        return datetime(1601, 1, 1) + timedelta(microseconds=ft / 10)
    except (OverflowError, OSError):
        return None


def safe_read_lines(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.readlines()


# --------------------------------------------------------------------------
# Shell history parsers (unchanged)
# --------------------------------------------------------------------------

def parse_bash_history(path):
    entries = []
    pending_ts = None
    for line in safe_read_lines(path):
        line = line.rstrip("\n")
        if not line:
            continue
        m = re.match(r"^#(\d{9,10})$", line.strip())
        if m:
            pending_ts = datetime.fromtimestamp(int(m.group(1))).isoformat()
            continue
        entries.append({"command": line, "timestamp": pending_ts})
        pending_ts = None
    return entries


def parse_zsh_history(path):
    entries = []
    for line in safe_read_lines(path):
        line = line.rstrip("\n")
        if not line:
            continue
        m = re.match(r"^: (\d+):(\d+);(.*)$", line)
        if m:
            entries.append({"command": m.group(3), "timestamp": datetime.fromtimestamp(int(m.group(1))).isoformat()})
        else:
            entries.append({"command": line, "timestamp": None})
    return entries


def parse_fish_history(path):
    entries = []
    current_cmd = None
    for line in safe_read_lines(path):
        stripped = line.strip()
        if stripped.startswith("- cmd:"):
            if current_cmd is not None:
                entries.append(current_cmd)
            current_cmd = {"command": stripped[len("- cmd:"):].strip(), "timestamp": None}
        elif stripped.startswith("when:") and current_cmd is not None:
            try:
                current_cmd["timestamp"] = datetime.fromtimestamp(int(stripped[len("when:"):].strip())).isoformat()
            except ValueError:
                pass
    if current_cmd is not None:
        entries.append(current_cmd)
    return entries


def parse_plain_history(path):
    return [{"command": l.rstrip("\n"), "timestamp": None} for l in safe_read_lines(path) if l.strip()]


LINUX_HISTORY_FILES = [
    (".bash_history", "bash", parse_bash_history),
    (".zsh_history", "zsh", parse_zsh_history),
    (".local/share/fish/fish_history", "fish", parse_fish_history),
    (".python_history", "python", parse_plain_history),
    (".mysql_history", "mysql", parse_plain_history),
    (".psql_history", "psql", parse_plain_history),
    (".rediscli_history", "redis-cli", parse_plain_history),
    (".sqlite_history", "sqlite3", parse_plain_history),
    (".node_repl_history", "node", parse_plain_history),
]


def detect_history_tampering(full_path, commands):
    """Heuristic flags for a cleared/truncated history file: near-empty
    despite the account clearly being used (home dir has other recent
    activity), or a modification time suspiciously close to file creation
    with very few lines for the account's apparent age.
    """
    flags = []
    times = stat_times(full_path)
    if "error" in times:
        return flags
    if len(commands) == 0:
        flags.append("History file exists but is completely empty -- consistent with "
                      "'history -c', '> ~/.bash_history', or HISTSIZE=0.")
    elif len(commands) < 3:
        flags.append(f"History file has only {len(commands)} line(s), which is unusually "
                      "low for an interactive account -- consistent with a recent clear "
                      "followed by a few new commands.")
    return flags


def collect_history_for_home(home_dir, username):
    entries = []
    for rel_path, tool, parser in LINUX_HISTORY_FILES:
        full_path = os.path.join(home_dir, rel_path)
        if not os.path.isfile(full_path):
            continue
        try:
            commands = parser(full_path)
        except (PermissionError, OSError) as e:
            entries.append({"user": username, "shell_or_tool": tool, "history_file": full_path, "error": str(e)})
            continue

        entry = {
            "user": username,
            "shell_or_tool": tool,
            "history_file": full_path,
            "file_times": stat_times(full_path),
            "command_count": len(commands),
            "commands": commands,
        }
        tamper_flags = detect_history_tampering(full_path, commands)
        if tamper_flags:
            entry["tamper_indicators"] = tamper_flags
        entries.append(entry)

    return entries


def collect_linux_command_history():
    entries = []
    current_home = os.path.expanduser("~")
    current_user = os.environ.get("USER") or os.environ.get("LOGNAME") or os.path.basename(current_home)
    entries.extend(collect_history_for_home(current_home, current_user))

    if current_home != "/root" and os.path.isdir("/root"):
        entries.extend(collect_history_for_home("/root", "root"))

    if os.path.isdir("/home"):
        try:
            for entry in os.listdir("/home"):
                candidate = os.path.join("/home", entry)
                if candidate == current_home or not os.path.isdir(candidate):
                    continue
                entries.extend(collect_history_for_home(candidate, entry))
        except PermissionError:
            pass

    return entries


# --------------------------------------------------------------------------
# auditd EXECVE cross-reference (independent of shell history files)
# --------------------------------------------------------------------------

def collect_auditd_execve_commands():
    """Reconstruct executed commands from auditd's independent log, which
    a user clearing their shell history cannot touch (requires root to
    tamper with, and tampering with auditd itself is loud).
    """
    log_path = "/var/log/audit/audit.log"
    if not os.path.isfile(log_path):
        return [], "auditd log not found (auditd may not be installed/running) -- no independent cross-check available."

    entries = []
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if "type=EXECVE" not in line:
                    continue
                ts_match = re.search(r"audit\((\d+)\.\d+:", line)
                ts = None
                if ts_match:
                    try:
                        ts = datetime.fromtimestamp(int(ts_match.group(1))).isoformat()
                    except (ValueError, OSError):
                        ts = None
                args = re.findall(r'a\d+="?([^"\s]+)"?', line)
                entries.append({"timestamp": ts, "argv": args, "raw_line": line.strip()})
    except PermissionError:
        return [], f"Permission denied reading {log_path}. Requires root."
    except OSError as e:
        return [], str(e)

    return entries, None


def cross_reference_gap(shell_histories, auditd_entries):
    """Surface the difference between what auditd saw executed and what
    shell history files currently contain -- a large gap suggests history
    was cleared at some point even if the file looks normal-sized now.
    """
    shell_commands = set()
    for h in shell_histories:
        for c in h.get("commands", []):
            cmd = (c.get("command") or "").strip()
            if cmd:
                shell_commands.add(cmd.split()[0] if cmd.split() else cmd)

    auditd_commands = set()
    for e in auditd_entries:
        if e.get("argv"):
            auditd_commands.add(os.path.basename(e["argv"][0]))

    only_in_auditd = sorted(auditd_commands - shell_commands)
    return {
        "distinct_binaries_in_shell_history": len(shell_commands),
        "distinct_binaries_in_auditd": len(auditd_commands),
        "binaries_seen_in_auditd_but_not_in_any_shell_history": only_in_auditd[:200],
        "interpretation": (
            "A non-empty list here does not by itself prove deletion (e.g. "
            "cron/service-invoked binaries never touch a shell history), "
            "but a large list combined with a suspiciously short/empty "
            "shell history file is a strong tampering indicator."
        ),
    }


# --------------------------------------------------------------------------
# Windows: PowerShell history + RunMRU + TypedPaths (unchanged) + UserAssist
# --------------------------------------------------------------------------

def collect_powershell_history_for_profile(appdata_roaming, username):
    history_path = os.path.join(appdata_roaming, "Microsoft", "Windows", "PowerShell", "PSReadLine", "ConsoleHost_history.txt")
    if not os.path.isfile(history_path):
        return None
    try:
        commands = parse_plain_history(history_path)
    except (PermissionError, OSError) as e:
        return {"user": username, "shell_or_tool": "powershell (PSReadLine)", "history_file": history_path, "error": str(e)}

    entry = {
        "user": username, "shell_or_tool": "powershell (PSReadLine)",
        "history_file": history_path, "file_times": stat_times(history_path),
        "command_count": len(commands), "commands": commands,
    }
    tamper_flags = detect_history_tampering(history_path, commands)
    if tamper_flags:
        entry["tamper_indicators"] = tamper_flags
    return entry


def collect_windows_powershell_history():
    entries = []
    appdata = os.environ.get("APPDATA")
    current_user = os.environ.get("USERNAME", "unknown")
    if appdata:
        result = collect_powershell_history_for_profile(appdata, current_user)
        if result:
            entries.append(result)

    system_drive = os.environ.get("SystemDrive", "C:")
    users_root = f"{system_drive}\\Users"
    if os.path.isdir(users_root):
        try:
            profiles = os.listdir(users_root)
        except PermissionError:
            profiles = []
        for profile in profiles:
            if profile == current_user:
                continue
            roaming = os.path.join(users_root, profile, "AppData", "Roaming")
            if not os.path.isdir(roaming):
                continue
            try:
                result = collect_powershell_history_for_profile(roaming, profile)
                if result:
                    entries.append(result)
            except PermissionError:
                entries.append({"user": profile, "shell_or_tool": "powershell (PSReadLine)", "error": "Permission denied"})
    return entries


def _read_registry_values(hive, subkey):
    if winreg is None:
        return
    try:
        with winreg.OpenKey(hive, subkey) as key:
            i = 0
            while True:
                try:
                    name, data, vtype = winreg.EnumValue(key, i)
                    yield name, data, vtype
                    i += 1
                except OSError:
                    break
    except (FileNotFoundError, PermissionError):
        return


def collect_windows_runmru():
    if winreg is None:
        return {"error": "winreg module unavailable (not running on Windows)"}
    base = r"Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU"
    entries, order = [], None
    for name, data, vtype in _read_registry_values(winreg.HKEY_CURRENT_USER, base):
        if name == "MRUList":
            order = data
            continue
        value = data[:-2] if isinstance(data, str) and data.endswith("\\1") else data
        entries.append({"artifact": "run_mru", "slot": name, "command": value})
    if order:
        entries.append({"artifact": "run_mru_order", "mru_order": order})
    return entries if entries else {"error": "RunMRU key empty or not found"}


def collect_windows_typed_paths():
    if winreg is None:
        return {"error": "winreg module unavailable (not running on Windows)"}
    base = r"Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths"
    entries = [{"artifact": "typed_path", "slot": name, "value": data}
               for name, data, vtype in _read_registry_values(winreg.HKEY_CURRENT_USER, base)]
    return entries if entries else {"error": "TypedPaths key empty or not found"}


def _rot13(s):
    return s.translate(str.maketrans(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
        "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm"
    ))


def collect_windows_userassist():
    """UserAssist: HKCU\\...\\UserAssist\\{GUID}\\Count holds ROT13-encoded
    paths of GUI programs launched via Explorer, with run count and last-run
    time (as a Windows FILETIME) -- independent of any shell/command history,
    and not something clearing PowerShell history touches at all.
    """
    if winreg is None:
        return {"error": "winreg module unavailable (not running on Windows)"}

    base = r"Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist"
    entries = []
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, base) as root:
            i = 0
            while True:
                try:
                    guid = winreg.EnumKey(root, i)
                except OSError:
                    break
                i += 1
                count_path = f"{base}\\{guid}\\Count"
                for name, data, vtype in _read_registry_values(winreg.HKEY_CURRENT_USER, count_path):
                    decoded_name = _rot13(name)
                    run_count, last_run_iso = None, None
                    if isinstance(data, (bytes, bytearray)) and len(data) >= 16:
                        try:
                            import struct
                            run_count = struct.unpack_from("<I", data, 4)[0]
                            ft = struct.unpack_from("<Q", data, 60)[0] if len(data) >= 68 else None
                            if ft:
                                last_run_iso_dt = filetime_to_datetime(ft)
                                last_run_iso = last_run_iso_dt.isoformat() if last_run_iso_dt else None
                        except struct.error:
                            pass
                    entries.append({
                        "guid": guid,
                        "decoded_path_or_name": decoded_name,
                        "run_count": run_count,
                        "last_run_time": last_run_iso,
                    })
    except (FileNotFoundError, PermissionError) as e:
        return {"error": str(e)}
    return entries if entries else {"error": "UserAssist key empty or not found"}


def collect_windows_command_history():
    ps_entries = collect_windows_powershell_history()
    return {
        "powershell_history": ps_entries,
        "run_mru": collect_windows_runmru(),
        "typed_paths": collect_windows_typed_paths(),
        "userassist_gui_program_history": collect_windows_userassist(),
        "note": "cmd.exe's Doskey command buffer is per-session, in-memory only, "
                "and is never persisted to disk by Windows -- there is nothing on "
                "disk to recover for plain cmd.exe history once the window closes. "
                "PowerShell (PSReadLine) IS persisted and is captured above.",
    }


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def collect_command_history(os_name):
    if os_name == "Windows":
        return collect_windows_command_history()
    elif os_name == "Linux":
        shell_histories = collect_linux_command_history()
        auditd_entries, auditd_err = collect_auditd_execve_commands()
        result = {"shell_histories": shell_histories}
        if auditd_err:
            result["auditd_execve"] = {"error": auditd_err}
        else:
            result["auditd_execve"] = {"count": len(auditd_entries), "entries": auditd_entries}
            result["shell_history_vs_auditd_gap"] = cross_reference_gap(shell_histories, auditd_entries)
        return result
    else:
        return {"error": f"Unsupported OS for command history collection: {os_name}. This module supports Windows and Linux."}


def _count_commands(section):
    if isinstance(section, dict) and "error" in section:
        return 0
    if isinstance(section, list):
        total = 0
        for item in section:
            if isinstance(item, dict) and "command_count" in item:
                total += item["command_count"]
            elif isinstance(item, dict):
                total += 1
        return total
    if isinstance(section, dict) and "entries" in section:
        return len(section["entries"])
    return 0


def save_evidence(results, os_name):
    totals = {k: _count_commands(v) for k, v in results.items()}
    payload = {
        "generated_at": datetime.now().isoformat(),
        "detected_os": os_name,
        "hostname": platform.node(),
        "totals_by_source": totals,
        "artifacts": results,
    }
    path, digest = write_json_evidence("command_history.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def main():
    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print("[*] Collecting command history evidence (with tamper detection)...")

    results = collect_command_history(os_name)

    for source_name, section in results.items():
        if isinstance(section, dict) and "error" in section:
            print(f"[!] {source_name}: {section['error']}")
        elif isinstance(section, dict) and "note" in section and source_name == "note":
            continue
        else:
            print(f"[*] {source_name}: {_count_commands(section)} record(s)")

    if os_name == "Linux":
        gap = results.get("shell_history_vs_auditd_gap")
        if gap:
            n = len(gap["binaries_seen_in_auditd_but_not_in_any_shell_history"])
            print(f"[i] {n} binaries seen executed via auditd that don't appear in any shell history file.")
        for h in results.get("shell_histories", []):
            if h.get("tamper_indicators"):
                print(f"[!] Possible tampering in {h['history_file']}: {'; '.join(h['tamper_indicators'])}")

    fname = save_evidence(results, os_name)
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
