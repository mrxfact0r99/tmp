"""
networks.py - Active network connection evidence collector.
Logic unchanged; now routed through common.py for consistent evidence
placement and chain-of-custody manifest entries.
"""

import os
import sys
import platform
from datetime import datetime

try:
    import psutil
except ImportError:
    psutil = None

try:
    from ..common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry

MODULE_NAME = "network_connections"


def get_process_name(pid):
    if pid is None or psutil is None:
        return None
    try:
        return psutil.Process(pid).name()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return "Unknown/Access Denied"


def collect_connections():
    if psutil is None:
        return {"error": "psutil not installed. Run: pip3 install psutil"}

    connections = []
    try:
        raw_conns = psutil.net_connections(kind="inet")
    except psutil.AccessDenied:
        return {"error": "Access denied reading connections. Run as Administrator (Windows) or with sudo (Linux/macOS) for full results."}

    for c in raw_conns:
        connections.append({
            "fd": c.fd, "family": str(c.family), "type": str(c.type),
            "local_address": f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else None,
            "remote_address": f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else None,
            "status": c.status, "pid": c.pid, "process_name": get_process_name(c.pid),
        })
    return connections


def save_evidence(connections, os_name):
    if isinstance(connections, dict) and "error" in connections:
        payload = {
            "generated_at": datetime.now().isoformat(), "detected_os": os_name,
            "hostname": platform.node(), "error": connections["error"],
        }
    else:
        payload = {
            "generated_at": datetime.now().isoformat(), "detected_os": os_name,
            "hostname": platform.node(), "total_connections": len(connections),
            "connections": connections,
        }
    path, digest = write_json_evidence("network_connections.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def main():
    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print("[*] Collecting current network connections...")

    connections = collect_connections()
    if isinstance(connections, dict) and "error" in connections:
        print(f"[!] {connections['error']}")
    else:
        print(f"[*] Found {len(connections)} connections.")

    fname = save_evidence(connections, os_name)
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
