"""
usb.py - USB device / removable media evidence collector.

UPGRADE NOTES ("which devices, external or pendrive, connected + any
read/write activity"):
The previous version was already fairly advanced (USBSTOR registry
history, NTFS USN Journal for write/create/delete/rename, SACL auditing
for read access on Windows). What it was missing, and what this version
adds:

  1. A direct answer to "what's plugged in right now" on every OS
     (`collect_currently_connected_devices`) -- not just event-log-derived
     activity, but live enumeration (Win32_PnPEntity/USBHub on Windows,
     /sys/bus/usb on Linux, `system_profiler SPUSBDataType` on macOS),
     including vendor/product IDs and serial numbers where exposed.
  2. Full historical USB connect/disconnect coverage on Linux: the old
     version only looked inside the journalctl time window; this version
     also greps ALL rotated syslog archives (*.gz, *.1, ...) so a device
     connected before the lookback window still shows up.
  3. macOS gets the same "currently connected" treatment it was missing
     entirely before (only login/USB *event log* scanning existed).

The Windows write/read auditing pipeline (USN Journal + SACL 4663 events)
is kept as-is since it was already solid -- just wired through the shared
common.py helpers for consistency.
"""

import os
import re
import sys
import glob
import gzip
import json
import platform
import subprocess
from datetime import datetime, timedelta

try:
    from ..common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry, get_logger, run_command, is_admin
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry, get_logger, run_command, is_admin

MODULE_NAME = "usb_devices"
MINUTES_BACK = 24 * 60
ENABLE_READ_WRITE_AUDIT = True


def run_powershell(script, timeout=90):
    try:
        return subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                               capture_output=True, text=True, timeout=timeout)
    except (FileNotFoundError, Exception):
        return None


# --------------------------------------------------------------------------
# NEW: "what's plugged in right now" -- direct, OS-native enumeration
# --------------------------------------------------------------------------

def collect_windows_connected_devices():
    ps_script = (
        "Get-CimInstance Win32_PnPEntity | "
        "Where-Object { $_.PNPDeviceID -like 'USB*' } | "
        "Select-Object Name, DeviceID, PNPDeviceID, Manufacturer, Status | ConvertTo-Json -Depth 3"
    )
    result = run_powershell(ps_script, timeout=30)
    if result is None or not (result.stdout or "").strip():
        return [], "Could not enumerate PnP USB devices (PowerShell unavailable or none found)."
    try:
        data = json.loads(result.stdout.strip())
        data = [data] if isinstance(data, dict) else data
    except json.JSONDecodeError:
        return [], "Could not parse PnP device enumeration JSON."

    devices = []
    for item in data:
        pnp_id = item.get("PNPDeviceID") or ""
        vid_match = re.search(r"VID_([0-9A-Fa-f]{4})", pnp_id)
        pid_match = re.search(r"PID_([0-9A-Fa-f]{4})", pnp_id)
        serial_match = re.search(r"\\([^\\&]+)$", pnp_id)
        devices.append({
            "name": item.get("Name"),
            "device_id": item.get("DeviceID"),
            "pnp_device_id": pnp_id,
            "manufacturer": item.get("Manufacturer"),
            "status": item.get("Status"),
            "vendor_id": vid_match.group(1) if vid_match else None,
            "product_id": pid_match.group(1) if pid_match else None,
            "serial_number_guess": serial_match.group(1) if serial_match else None,
        })
    return devices, None


def collect_linux_connected_devices():
    """Enumerate live USB devices from /sys/bus/usb/devices -- works
    without root and without any external tool (lsusb not required, though
    used as a fallback/cross-check if present).
    """
    devices = []
    sys_path = "/sys/bus/usb/devices"
    if os.path.isdir(sys_path):
        for entry in os.listdir(sys_path):
            dev_dir = os.path.join(sys_path, entry)
            product_file = os.path.join(dev_dir, "product")
            if not os.path.isfile(product_file):
                continue  # skip interfaces/hubs without a product string

            def _read(name):
                p = os.path.join(dev_dir, name)
                if os.path.isfile(p):
                    try:
                        with open(p, "r", errors="replace") as f:
                            return f.read().strip()
                    except OSError:
                        return None
                return None

            devices.append({
                "sysfs_path": dev_dir,
                "product": _read("product"),
                "manufacturer": _read("manufacturer"),
                "serial": _read("serial"),
                "vendor_id": _read("idVendor"),
                "product_id": _read("idProduct"),
                "device_class": _read("bDeviceClass"),
                "speed_mbps": _read("speed"),
            })

    if not devices:
        stdout, err = run_command(["lsusb"], timeout=10)
        if stdout:
            for line in stdout.strip().splitlines():
                devices.append({"raw_lsusb_line": line.strip()})

    return devices, (None if devices else "No USB devices found via /sys/bus/usb/devices or lsusb.")


def collect_macos_connected_devices():
    stdout, err = run_command(["system_profiler", "SPUSBDataType", "-json"], timeout=30)
    if not stdout:
        return [], (err or "system_profiler returned no data.")
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        return [], "Could not parse system_profiler JSON output."

    devices = []

    def _walk(items):
        for item in items:
            devices.append({
                "name": item.get("_name"),
                "vendor_id": item.get("vendor_id"),
                "product_id": item.get("product_id"),
                "serial_number": item.get("serial_num"),
                "manufacturer": item.get("manufacturer"),
                "removable_media": item.get("removable_media"),
            })
            if "_items" in item:
                _walk(item["_items"])

    _walk(data.get("SPUSBDataType", []))
    return devices, None


def collect_currently_connected_devices(os_name):
    if os_name == "Windows":
        return collect_windows_connected_devices()
    elif os_name == "Linux":
        return collect_linux_connected_devices()
    elif os_name == "macOS":
        return collect_macos_connected_devices()
    return [], f"Unsupported OS: {os_name}"


# --------------------------------------------------------------------------
# Windows: USBSTOR history, USN journal writes, SACL read/write audit
# (kept from the previous version, routed through common.py)
# --------------------------------------------------------------------------

def collect_windows_usb(minutes_back):
    events, note = [], None
    ps_script = f"""
    $ErrorActionPreference = 'SilentlyContinue'
    Get-WinEvent -FilterHashtable @{{
        LogName='Microsoft-Windows-DriverFrameworks-UserMode/Operational'
        StartTime=(Get-Date).AddMinutes(-{minutes_back})
    }} 2>$null | Select-Object TimeCreated, Id, LevelDisplayName, Message | ConvertTo-Json -Depth 3
    """
    result = run_powershell(ps_script)
    if result is None:
        note = "PowerShell not found - this does not look like Windows."
    else:
        raw = result.stdout.strip()
        if raw:
            try:
                data = json.loads(raw)
                data = [data] if isinstance(data, dict) else data
                for item in data:
                    events.append({
                        "time": item.get("TimeCreated"), "event_id": item.get("Id"),
                        "level": item.get("LevelDisplayName"),
                        "description": (item.get("Message") or "")[:300],
                    })
            except json.JSONDecodeError:
                note = "Could not parse DriverFrameworks-UserMode log output."

    if not events and note is None:
        note = ("No device-install events found in this window. This can happen if the "
                 "log rolled over, or if the device was already installed before and "
                 "Windows only logs first-time installs. See 'usbstor_history' for the "
                 "full list of USB storage devices ever connected to this machine.")

    return events, note, collect_usb_registry_history()


def collect_usb_registry_history():
    devices = []
    try:
        import winreg
    except ImportError:
        return devices

    base = r"SYSTEM\CurrentControlSet\Enum\USBSTOR"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as key:
            i = 0
            while True:
                try:
                    device_class = winreg.EnumKey(key, i)
                except OSError:
                    break
                i += 1
                try:
                    with winreg.OpenKey(key, device_class) as class_key:
                        j = 0
                        while True:
                            try:
                                serial = winreg.EnumKey(class_key, j)
                            except OSError:
                                break
                            j += 1
                            friendly_name = device_class
                            try:
                                with winreg.OpenKey(class_key, serial) as inst_key:
                                    try:
                                        friendly_name = winreg.QueryValueEx(inst_key, "FriendlyName")[0]
                                    except FileNotFoundError:
                                        pass
                            except OSError:
                                pass
                            devices.append({"device_class": device_class, "serial_number": serial, "friendly_name": friendly_name})
                except OSError:
                    continue
    except (FileNotFoundError, Exception):
        pass
    return devices


def get_removable_drives():
    drives = []
    ps_script = "Get-CimInstance Win32_LogicalDisk -Filter \"DriveType=2\" | Select-Object DeviceID | ConvertTo-Json"
    result = run_powershell(ps_script, timeout=30)
    if result is None or not (result.stdout or "").strip():
        return drives
    try:
        data = json.loads(result.stdout.strip())
        data = [data] if isinstance(data, dict) else data
        for item in data:
            dev = item.get("DeviceID")
            if dev:
                drives.append(dev)
    except json.JSONDecodeError:
        pass
    return drives


USN_REASON_FLAGS = [
    (0x00000001, "Data overwritten"), (0x00000002, "Data extended (written/appended)"),
    (0x00000004, "Data truncated"), (0x00000010, "Named data stream overwritten"),
    (0x00000020, "Named data stream extended"), (0x00000040, "Named data stream truncated"),
    (0x00000100, "File/dir created"), (0x00000200, "File/dir deleted"),
    (0x00000400, "Extended attributes changed"), (0x00000800, "Security/ACL changed"),
    (0x00001000, "Renamed (old name)"), (0x00002000, "Renamed (new name)"),
    (0x00008000, "Basic info changed (timestamps/attributes)"),
    (0x00020000, "Compression state changed"), (0x00040000, "Encryption changed"),
    (0x00100000, "Reparse point changed"), (0x00200000, "Alternate data stream changed"),
    (0x80000000, "File/dir closed"),
]


def decode_usn_reason(reason_field):
    if reason_field is None:
        return []
    text = str(reason_field).strip()
    if text.lower().startswith("0x"):
        try:
            value = int(text, 16)
        except ValueError:
            return [text]
        return [label for bit, label in USN_REASON_FLAGS if value & bit]
    return [p.strip() for p in text.split(",") if p.strip()]


def collect_usb_write_operations(minutes_back):
    events, note = [], None
    if not is_admin():
        return events, "Reading the USN Journal requires Administrator privileges. Re-run as Administrator to see file write/create/delete history for the USB drive."

    drives = get_removable_drives()
    if not drives:
        return events, "No removable drive currently connected. Plug the USB device in before running the script to see file activity on it."

    cutoff = datetime.now() - timedelta(minutes=minutes_back)
    for drive in drives:
        subprocess.run(["fsutil", "usn", "createjournal", "m=1000", "a=100", drive], capture_output=True, text=True, timeout=15)
        try:
            result = subprocess.run(["fsutil", "usn", "readjournal", drive, "csv"], capture_output=True, text=True, timeout=90)
        except Exception as e:
            note = f"Error reading USN journal on {drive}: {e}"
            continue
        if result.returncode != 0 or not result.stdout.strip():
            if note is None:
                note = f"Could not read USN journal on {drive} (empty or unsupported on this drive/filesystem)."
            continue

        lines = [l for l in result.stdout.splitlines() if l.strip()]
        if len(lines) <= 1:
            continue
        header = [h.strip().strip('"') for h in lines[0].split(",")]

        def col(row, name):
            try:
                return row[header.index(name)].strip().strip('"')
            except (ValueError, IndexError):
                return None

        for line in lines[1:]:
            row = line.split(",")
            timestamp_raw = col(row, "Time Stamp") or col(row, "TimeStamp")
            filename = col(row, "File name") or col(row, "FileName")
            reason = col(row, "Reason")
            ts = None
            if timestamp_raw:
                for fmt in ("%m/%d/%Y %H:%M:%S", "%m/%d/%Y %I:%M:%S %p"):
                    try:
                        ts = datetime.strptime(timestamp_raw, fmt)
                        break
                    except ValueError:
                        continue
            if ts is not None and ts < cutoff:
                continue
            events.append({"drive": drive, "time": timestamp_raw, "file_name": filename, "operations": decode_usn_reason(reason)})

    if not events and note is None:
        note = "No write/create/delete/rename activity found on connected removable drives in this window."
    return events, note


def enable_read_write_auditing(drives):
    if not drives:
        return None
    if not is_admin():
        return "Enabling read/write auditing requires Administrator privileges."
    subprocess.run(["auditpol", "/set", "/subcategory:File System", "/success:enable", "/failure:enable"],
                    capture_output=True, text=True, timeout=15)
    for drive in drives:
        path = drive + "\\"
        ps_script = f"""
        $ErrorActionPreference = 'SilentlyContinue'
        $path = '{path}'
        $acl = Get-Acl -Path $path -Audit
        $rule = New-Object System.Security.AccessControl.FileSystemAuditRule(
            'Everyone', 'ReadData,WriteData', 'ContainerInherit,ObjectInherit', 'None', 'Success')
        $acl.AddAuditRule($rule)
        Set-Acl -Path $path -AclObject $acl -Audit
        """
        run_powershell(ps_script, timeout=30)
    return None


def collect_read_write_audit_events(minutes_back, drives):
    events, note = [], None
    if not is_admin():
        return events, "Reading the Security log requires Administrator privileges."
    if not drives:
        return events, "No removable drive connected - nothing to audit."

    ps_script = f"""
    $ErrorActionPreference = 'SilentlyContinue'
    Get-WinEvent -FilterHashtable @{{
        LogName='Security'; Id=4663; StartTime=(Get-Date).AddMinutes(-{minutes_back})
    }} 2>$null | Select-Object TimeCreated, Message | ConvertTo-Json -Depth 3
    """
    result = run_powershell(ps_script, timeout=90)
    if result is None:
        return events, "PowerShell not found - this does not look like Windows."
    raw = result.stdout.strip()
    if not raw:
        return events, "No read/write access events found yet. Auditing only covers activity from the moment it was enabled this run onward - access the drive, then re-run."
    try:
        data = json.loads(raw)
        data = [data] if isinstance(data, dict) else data
    except json.JSONDecodeError:
        return events, "Could not parse Security log output."

    for item in data:
        msg = item.get("Message") or ""
        if not any(d.rstrip(":") in msg for d in drives):
            continue
        path_match = re.search(r"Object Name:\s*(.+)", msg)
        access_match = re.search(r"Accesses:\s*\n?\s*(.+)", msg)
        accesses = access_match.group(1).strip() if access_match else ""
        op = []
        if "ReadData" in accesses or "Read Data" in accesses:
            op.append("Read")
        if "WriteData" in accesses or "Write Data" in accesses:
            op.append("Write")
        if not op:
            continue
        events.append({"time": item.get("TimeCreated"), "file_name": path_match.group(1).strip() if path_match else None, "operations": op})

    if not events and note is None:
        note = "No matching read/write events for the connected drive(s) in this window yet."
    return events, note


def collect_windows_logins(minutes_back):
    events, note = [], None
    if not is_admin():
        return events, "Security log requires Administrator privileges. Right-click PowerShell/CMD -> 'Run as Administrator', then re-run this script."

    try:
        subprocess.run(["auditpol", "/set", "/subcategory:Logon", "/success:enable", "/failure:enable"], capture_output=True, text=True, timeout=15)
    except Exception:
        pass

    ps_script = f"""
    $ErrorActionPreference = 'SilentlyContinue'
    Get-WinEvent -FilterHashtable @{{
        LogName='Security'; Id=4624,4625,4634,4647; StartTime=(Get-Date).AddMinutes(-{minutes_back})
    }} 2>$null | Select-Object TimeCreated, Id, Message | ConvertTo-Json -Depth 3
    """
    result = run_powershell(ps_script)
    if result is None:
        note = "PowerShell not found - this does not look like Windows."
    else:
        raw = result.stdout.strip()
        if raw:
            try:
                data = json.loads(raw)
                data = [data] if isinstance(data, dict) else data
                for item in data:
                    msg = item.get("Message") or ""
                    account_match = re.search(r"Account Name:\s*(.+)", msg)
                    events.append({"time": item.get("TimeCreated"), "event_id": item.get("Id"),
                                   "account": account_match.group(1).strip() if account_match else None,
                                   "description": msg[:300]})
            except json.JSONDecodeError:
                note = "Could not parse Security log output."

    if not events and note is None:
        note = "No login events found in this window. Auditing has just been (re)enabled for future logons -- if this is a fresh enable, log out/in once and re-run to see results."
    return events, note


# --------------------------------------------------------------------------
# Linux: kernel USB events, now including ALL rotated syslog archives
# --------------------------------------------------------------------------

def collect_linux_usb(minutes_back):
    events, note = [], None
    since = f"-{minutes_back}min"
    try:
        result = subprocess.run(["journalctl", "-k", "--since", since, "--no-pager", "-o", "short-iso"],
                                 capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            note = "Could not read kernel log via journalctl. Try running with sudo."
        else:
            lines = [l for l in result.stdout.splitlines() if "usb" in l.lower()]
            events = [{"raw": l, "source": "journalctl -k"} for l in lines]
    except FileNotFoundError:
        try:
            result = subprocess.run(["dmesg"], capture_output=True, text=True, timeout=30)
            lines = [l for l in result.stdout.splitlines() if "usb" in l.lower()]
            events = [{"raw": l, "source": "dmesg"} for l in lines]
        except Exception as e:
            note = f"Neither journalctl nor dmesg available: {e}"
    except Exception as e:
        note = f"Error reading USB events: {e}"

    # Full historical coverage: grep every rotated syslog/kern.log archive too,
    # not just what's inside the journalctl time window.
    rotated_events = []
    for pattern in ("/var/log/syslog.*", "/var/log/kern.log.*"):
        for path in sorted(glob.glob(pattern)):
            try:
                opener = gzip.open if path.endswith(".gz") else open
                with opener(path, "rt", errors="replace") as f:
                    for line in f:
                        if "usb" in line.lower():
                            rotated_events.append({"raw": line.strip(), "source": os.path.basename(path)})
            except (OSError, EOFError):
                continue

    all_events = events + rotated_events
    if not all_events and note is None:
        note = "No USB-related kernel messages found in this window or in rotated syslog archives."
    return all_events, note


def collect_linux_logins(minutes_back):
    events, note = [], None
    try:
        result = subprocess.run(["last", "-F"], capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout.strip():
            for line in result.stdout.splitlines():
                if line.strip() and not line.startswith("wtmp begins"):
                    events.append({"source": "last(wtmp)", "raw": line.strip()})
    except FileNotFoundError:
        pass
    except Exception as e:
        note = f"Error running 'last': {e}"

    try:
        since = f"-{minutes_back}min"
        result = subprocess.run(["journalctl", "-u", "systemd-logind", "--since", since, "--no-pager", "-o", "short-iso"],
                                 capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if line.strip():
                    events.append({"source": "systemd-logind", "raw": line.strip()})
    except (FileNotFoundError, Exception):
        pass

    if not events and note is None:
        note = "No login events found. Try running with sudo, or check /var/log/auth.log directly (Debian/Ubuntu)."
    return events, note


def collect_macos_usb(minutes_back):
    events, note = [], None
    cmd = ["log", "show", "--last", f"{minutes_back}m",
           "--predicate", 'eventMessage contains "USB" or eventMessage contains "IOUSBHost"', "--style", "compact"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        if result.returncode != 0:
            note = "Could not read unified log. Run with sudo."
        else:
            lines = [l for l in result.stdout.splitlines() if l.strip()]
            events = [{"raw": l} for l in lines]
            if not events:
                note = "No USB-related entries found in this window."
    except FileNotFoundError:
        note = "'log' command not found - this does not look like macOS."
    except Exception as e:
        note = f"Error reading USB events: {e}"
    return events, note


def collect_macos_logins(minutes_back):
    events, note = [], None
    cmd = ["log", "show", "--last", f"{minutes_back}m",
           "--predicate", 'eventMessage contains "loginwindow" or process == "loginwindow"', "--style", "compact"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        if result.returncode != 0:
            note = "Could not read unified log. Run with sudo."
        else:
            lines = [l for l in result.stdout.splitlines() if l.strip()]
            events = [{"raw": l} for l in lines]
            if not events:
                note = "No login-related entries found in this window."
    except FileNotFoundError:
        note = "'log' command not found - this does not look like macOS."
    except Exception as e:
        note = f"Error reading login events: {e}"
    return events, note


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def save_evidence(payload):
    path, digest = write_json_evidence("usb_devices_and_activity.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def collect():
    os_name = detect_os()
    admin = is_admin()

    connected_devices, connected_note = collect_currently_connected_devices(os_name)

    usb_history = []
    write_events, write_note = [], None
    audit_events, audit_note = [], None

    if os_name == "Windows":
        usb_events, usb_note, usb_history = collect_windows_usb(MINUTES_BACK)
        login_events, login_note = collect_windows_logins(MINUTES_BACK)
        write_events, write_note = collect_usb_write_operations(MINUTES_BACK)
        drives = get_removable_drives()
        if ENABLE_READ_WRITE_AUDIT and drives:
            audit_err = enable_read_write_auditing(drives)
            if audit_err:
                audit_note = audit_err
            else:
                audit_events, audit_note = collect_read_write_audit_events(MINUTES_BACK, drives)
    elif os_name == "Linux":
        usb_events, usb_note = collect_linux_usb(MINUTES_BACK)
        login_events, login_note = collect_linux_logins(MINUTES_BACK)
    elif os_name == "macOS":
        usb_events, usb_note = collect_macos_usb(MINUTES_BACK)
        login_events, login_note = collect_macos_logins(MINUTES_BACK)
    else:
        usb_events, usb_note = [], f"Unsupported OS: {os_name}"
        login_events, login_note = [], f"Unsupported OS: {os_name}"

    payload = {
        "generated_at": datetime.now().isoformat(),
        "detected_os": os_name,
        "hostname": platform.node(),
        "ran_as_admin": admin,
        "window_minutes": MINUTES_BACK,
        "currently_connected_devices": {
            "count": len(connected_devices), "devices": connected_devices, "note": connected_note,
        },
        "usb_events": {"count": len(usb_events), "events": usb_events, "note": usb_note},
        "login_events": {"count": len(login_events), "events": login_events, "note": login_note},
    }

    if os_name == "Windows":
        payload["usbstor_history"] = {
            "count": len(usb_history), "devices": usb_history,
            "note": "Full list of USB storage devices ever connected (from registry, no timestamp).",
        }
        payload["file_operations"] = {
            "writes_creates_deletes_renames": {
                "count": len(write_events), "events": write_events, "note": write_note,
                "source": "NTFS USN Journal - retroactive, no setup required.",
            },
            "read_write_audit": {
                "count": len(audit_events), "events": audit_events, "note": audit_note,
                "source": "Security log event 4663 via SACL auditing - only covers activity "
                          "from when auditing was enabled onward, cannot see past reads.",
                "enabled": ENABLE_READ_WRITE_AUDIT,
            },
        }

    return payload


def main():
    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print(f"[*] Looking back: {MINUTES_BACK} minutes ({MINUTES_BACK // 60} hours)")

    if not is_admin():
        print("[!] Warning: not running as admin/root - login events (and possibly some USB events) "
              "will be incomplete or empty. Re-run elevated for full results.")

    payload = collect()

    print(f"[*] Currently connected USB devices: {payload['currently_connected_devices']['count']}")
    if payload['currently_connected_devices']['note']:
        print(f"[i] {payload['currently_connected_devices']['note']}")
    print(f"[*] USB events found: {payload['usb_events']['count']}")
    if payload['usb_events']['note']:
        print(f"[i] USB note: {payload['usb_events']['note']}")
    if os_name == "Windows":
        print(f"[*] USB storage devices in registry history: {payload['usbstor_history']['count']}")
        fo = payload["file_operations"]
        print(f"[*] Write/create/delete/rename events found: {fo['writes_creates_deletes_renames']['count']}")
        print(f"[*] Read/write audit events found: {fo['read_write_audit']['count']}")
    print(f"[*] Login events found: {payload['login_events']['count']}")

    fname = save_evidence(payload)
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
