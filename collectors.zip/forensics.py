#!/usr/bin/env python3
"""
forensics.py - Main entry point / orchestrator for the evidence toolkit.

WHAT THIS ADDS ON TOP OF THE INDIVIDUAL COLLECTOR SCRIPTS:

  1. Runs every collector module and NEVER lets one module's failure or
     slowness stop the rest of the report ("without interrupt report
     generation"). Each collector runs inside common.safe_collect / its own
     try/except, failures are logged to run.log and recorded in the final
     report as {"error": ...} for that module, and the run continues.
  2. Runs collectors concurrently (ThreadPoolExecutor) since they're almost
     entirely I/O-bound (subprocess calls, file/registry reads) -- this
     makes a full run much faster than running each script one at a time.
  3. Starts the clipboard background monitor FIRST, before any other
     collector, so it's been sampling the live clipboard for the entire
     duration of the run by the time the clipboard module finally writes
     its evidence -- giving real history instead of one snapshot.
  4. Produces a single case folder (Evidences/case_<timestamp>/) containing
     every module's JSON, a run.log, a manifest.json (chain of custody:
     each evidence file's SHA-256, when it was written, by which module),
     and a top-level summary.json + summary.html tying it all together.
  5. Lets you select which modules to run, and how long to keep the
     clipboard monitor sampling, from the command line.

Usage:
    python forensics.py                      # run everything
    python forensics.py --modules usb,logs   # run a subset
    python forensics.py --clipboard-seconds 30   # sample clipboard for 30s
    python forensics.py --list               # list available modules
"""

import os
import sys
import json
import time
import platform
import argparse
import traceback
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from common import (
    EVIDENCE_DIR, detect_os, ensure_evidence_dir, is_admin, get_logger,
    write_json_evidence, sha256_file, print_status,
)

# Import collectors as a package-relative set (forensics.py sits next to
# common.py, collectors/ is the sibling package).
from collectors import clipboard as mod_clipboard
from collectors import commands as mod_commands
from collectors import history as mod_history
from collectors import logs as mod_logs
from collectors import networks as mod_networks
from collectors import processes as mod_processes
from collectors import recycle as mod_recycle
from collectors import usb as mod_usb
from collectors import execution as mod_execution

MODULES = {
    "clipboard": {
        "label": "Clipboard (live + history + monitor)",
        "run": lambda: mod_clipboard.collect(),
        "save": lambda result: mod_clipboard.save_evidence(result),
    },
    "commands": {
        "label": "Command history (with tamper detection)",
        "run": lambda: mod_commands.collect_command_history(detect_os()),
        "save": lambda result: mod_commands.save_evidence(result, detect_os()),
    },
    "history": {
        "label": "Browser history (with deleted-URL carving)",
        "run": lambda: mod_history.collect(),
        "save": lambda result: mod_history.save_evidence(result),
    },
    "logs": {
        "label": "System logs (with clear-event detection)",
        "run": lambda: mod_logs.collect_logs(detect_os()),
        "save": lambda result: mod_logs.save_evidence(result, detect_os()),
    },
    "networks": {
        "label": "Active network connections",
        "run": lambda: mod_networks.collect_connections(),
        "save": lambda result: mod_networks.save_evidence(result, detect_os()),
    },
    "processes": {
        "label": "Running processes",
        "run": lambda: mod_processes.collect_processes(),
        "save": lambda result: mod_processes.save_evidence(result, detect_os()),
    },
    "recycle": {
        "label": "Recycle Bin / Trash (+ file recovery)",
        "run": None,   # set below (needs multi-step run+recover)
        "save": None,  # set below
    },
    "usb": {
        "label": "USB devices, history & read/write activity",
        "run": lambda: mod_usb.collect(),
        "save": lambda result: mod_usb.save_evidence(result),
    },
    "execution": {
        "label": "Executed programs (processes/prefetch/shimcache/tasks/services)",
        "run": lambda: mod_execution.collect_executed_programs(detect_os()),
        "save": lambda result: mod_execution.save_evidence(result, detect_os()),
    },
}


def _recycle_run():
    os_name = detect_os()
    entries = mod_recycle.collect_recycle_bin(os_name)
    entries, recovered_count = mod_recycle.recover_files(entries)
    return {"entries": entries, "recovered_count": recovered_count}


def _recycle_save(result):
    os_name = detect_os()
    return mod_recycle.save_evidence(result["entries"], os_name)


MODULES["recycle"]["run"] = _recycle_run
MODULES["recycle"]["save"] = _recycle_save


def run_module(name, spec, logger):
    start = time.time()
    try:
        result = spec["run"]()
        path = spec["save"](result)
        digest = sha256_file(path) if path else None
        elapsed = time.time() - start
        logger.info(f"{name}: OK in {elapsed:.2f}s -> {path}")
        return {
            "module": name, "label": spec["label"], "status": "ok",
            "evidence_file": os.path.basename(path) if path else None,
            "sha256": digest, "elapsed_seconds": round(elapsed, 2),
        }
    except Exception as e:
        elapsed = time.time() - start
        tb = traceback.format_exc()
        logger.error(f"{name}: FAILED after {elapsed:.2f}s\n{tb}")
        return {
            "module": name, "label": spec["label"], "status": "error",
            "error": f"{type(e).__name__}: {e}", "elapsed_seconds": round(elapsed, 2),
        }


def build_html_summary(summary):
    rows = "".join(
        f"<tr class='{r['status']}'><td>{r['module']}</td><td>{r['label']}</td>"
        f"<td>{r['status'].upper()}</td><td>{r.get('evidence_file','')}</td>"
        f"<td>{r.get('elapsed_seconds','')}s</td>"
        f"<td>{r.get('error','') if r['status']=='error' else r.get('sha256','')[:16]+'&hellip;' if r.get('sha256') else ''}</td></tr>"
        for r in summary["modules"]
    )
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Forensic Evidence Summary</title>
<style>
body {{ font-family: -apple-system, Segoe UI, Arial, sans-serif; margin: 2rem; background:#0b0f14; color:#e6edf3; }}
h1 {{ font-size: 1.4rem; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
th, td {{ border: 1px solid #30363d; padding: 8px 10px; text-align: left; font-size: 0.9rem; }}
th {{ background: #161b22; }}
tr.ok td:nth-child(3) {{ color: #3fb950; font-weight: 600; }}
tr.error td:nth-child(3) {{ color: #f85149; font-weight: 600; }}
.meta {{ color: #8b949e; font-size: 0.85rem; }}
</style></head>
<body>
<h1>Forensic Evidence Summary</h1>
<p class="meta">Case: {summary['case_id']} &middot; Host: {summary['hostname']} &middot; OS: {summary['detected_os']}
&middot; Generated: {summary['generated_at']} &middot; Ran as admin/root: {summary['ran_as_admin']}</p>
<table>
<tr><th>Module</th><th>Description</th><th>Status</th><th>Evidence file</th><th>Time</th><th>SHA-256 / Error</th></tr>
{rows}
</table>
<p class="meta">Full chain-of-custody hashes for every evidence file are in manifest.json in this case folder.</p>
</body></html>"""


def main():
    parser = argparse.ArgumentParser(description="Run the full forensic evidence toolkit.")
    parser.add_argument("--modules", type=str, default=None,
                         help=f"Comma-separated subset to run. Available: {','.join(MODULES.keys())}")
    parser.add_argument("--list", action="store_true", help="List available modules and exit.")
    parser.add_argument("--clipboard-seconds", type=int, default=15,
                         help="How long (seconds) to let the clipboard monitor sample in the "
                              "background while other modules run (default: 15).")
    parser.add_argument("--workers", type=int, default=6, help="Max concurrent collector threads.")
    args = parser.parse_args()

    if args.list:
        for name, spec in MODULES.items():
            print(f"  {name:12s} - {spec['label']}")
        return

    selected = list(MODULES.keys())
    if args.modules:
        requested = [m.strip() for m in args.modules.split(",") if m.strip()]
        unknown = [m for m in requested if m not in MODULES]
        if unknown:
            print(f"[!] Unknown module(s): {', '.join(unknown)}. Available: {', '.join(MODULES.keys())}")
            sys.exit(1)
        selected = requested

    os_name = detect_os()
    ensure_evidence_dir()
    logger = get_logger()

    print_status(f"[*] Case folder: {EVIDENCE_DIR}")
    print_status(f"[*] Detected OS: {os_name}  |  Host: {platform.node()}  |  Admin/root: {is_admin()}")
    print_status(f"[*] Running modules: {', '.join(selected)}")

    # Start the clipboard monitor first (if clipboard module selected) so
    # it's sampling for the whole run duration, not just an instant.
    if "clipboard" in selected:
        print_status(f"[*] Starting background clipboard monitor ({args.clipboard_seconds}s minimum window)...")
        mod_clipboard.start_background_monitor(os_name, poll_interval=1.0)

    results = []
    start_all = time.time()
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {}
        for name in selected:
            if name == "clipboard":
                continue  # run last, after its monitor window has elapsed
            print_status(f"[*] Launching: {MODULES[name]['label']}")
            futures[executor.submit(run_module, name, MODULES[name], logger)] = name

        for future in as_completed(futures):
            name = futures[future]
            result = future.result()
            results.append(result)
            status_icon = "+" if result["status"] == "ok" else "!"
            print_status(f"[{status_icon}] {name}: {result['status']} ({result.get('elapsed_seconds')}s)")

    if "clipboard" in selected:
        remaining = args.clipboard_seconds - (time.time() - start_all)
        if remaining > 0:
            print_status(f"[*] Waiting {remaining:.0f}s more for clipboard monitor window...")
            time.sleep(remaining)
        print_status("[*] Finalizing clipboard evidence...")
        result = run_module("clipboard", MODULES["clipboard"], logger)
        results.append(result)
        status_icon = "+" if result["status"] == "ok" else "!"
        print_status(f"[{status_icon}] clipboard: {result['status']} ({result.get('elapsed_seconds')}s)")

    elapsed_total = time.time() - start_all
    ok_count = sum(1 for r in results if r["status"] == "ok")
    err_count = len(results) - ok_count

    summary = {
        "case_id": os.path.basename(EVIDENCE_DIR),
        "generated_at": datetime.now().isoformat(),
        "hostname": platform.node(),
        "detected_os": os_name,
        "ran_as_admin": is_admin(),
        "total_elapsed_seconds": round(elapsed_total, 2),
        "modules_ok": ok_count,
        "modules_failed": err_count,
        "modules": sorted(results, key=lambda r: r["module"]),
    }

    summary_path, _ = write_json_evidence("summary.json", summary)
    html_path = os.path.join(EVIDENCE_DIR, "summary.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(build_html_summary(summary))

    print_status("")
    print_status(f"[+] Run complete in {elapsed_total:.1f}s: {ok_count} module(s) OK, {err_count} failed.")
    if err_count:
        for r in results:
            if r["status"] == "error":
                print_status(f"    [!] {r['module']}: {r['error']}")
    print_status(f"[+] Case folder: {EVIDENCE_DIR}")
    print_status(f"[+] Summary: {summary_path}")
    print_status(f"[+] HTML summary: {html_path}")
    print_status(f"[+] Chain-of-custody manifest: {os.path.join(EVIDENCE_DIR, 'manifest.json')}")
    print_status(f"[+] Run log: {os.path.join(EVIDENCE_DIR, 'run.log')}")


if __name__ == "__main__":
    main()
