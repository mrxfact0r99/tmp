"""
logs.py - System log evidence collector.

UPGRADE NOTES:
The old version only pulled the *currently live* window of each log
source. This version adds two things aimed at "deleted system logs":

  1. Log-clearing DETECTION. Overwriting/clearing a system log is itself
     an event that gets logged:
       - Windows: Event ID 1102 ("The audit log was cleared") in the
         Security log, and Event ID 104 ("Log clear") in the
         Microsoft-Windows-Eventlog/Operational channel for other logs.
         Both record who cleared it and when -- this is one of the most
         useful anti-forensics indicators there is, so it's now collected
         explicitly and surfaced at the top of the report.
       - Linux: journald's binary logs are sequence-numbered; a gap in
         sequence numbers or a "boot ID" that restarts unexpectedly is
         evidence of log tampering/deletion. `journalctl --verify` is run
         to catch corruption, and rotated/archived files are enumerated so
         nothing already rotated-but-still-on-disk is missed.

  2. Recovery of ALREADY-ROTATED / ARCHIVED logs still sitting on disk.
     Windows keeps `Archive-<LogName>-*.evtx` backups when configured to
     do so; Linux keeps `*.gz`/`*.1` rotated syslog/journal files. These
     are not "deleted" in the sense of gone, but the live/base collector
     never looked at them -- they are now enumerated and their content
     pulled in as additional evidence.

Honesty note: once a log entry is genuinely overwritten in a
size-capped/circular log with no rotation backup and no VSS/backup copy,
it is not recoverable by this tool. This module maximizes what's legally
and technically retrievable (backups, rotations, clear-events) and is
explicit in the report about what it could and couldn't find.
"""

import os
import re
import json
import glob
import gzip
import platform
import subprocess
from datetime import datetime, timezone

try:
    from ..common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry, get_logger, run_command
except ImportError:
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry, get_logger, run_command

MODULE_NAME = "system_logs"
MAX_EVENTS = 1000

_SYSLOG_LEVEL_MAP = {
    "0": "Emergency", "1": "Alert", "2": "Critical", "3": "Error",
    "4": "Warning", "5": "Notice", "6": "Information", "7": "Debug",
}


# --------------------------------------------------------------------------
# Windows: live logs (unchanged) + clear-event detection + archive recovery
# --------------------------------------------------------------------------

def collect_windows_logs(max_events=MAX_EVENTS):
    logs = {}
    log_names = ["System", "Application", "Security"]

    for log_name in log_names:
        ps_cmd = [
            "powershell", "-NoProfile", "-Command",
            (
                f"Get-WinEvent -LogName {log_name} -MaxEvents {max_events} "
                "-ErrorAction Stop | "
                "Select-Object TimeCreated, Id, LevelDisplayName, "
                "ProviderName, Message | ConvertTo-Json -Depth 4"
            ),
        ]
        stdout, err = run_command(ps_cmd, timeout=90)
        if err or not stdout:
            logs[log_name] = {"error": err or f"Could not read {log_name} log "
                               "(Security log usually requires Administrator)."}
            continue
        raw = stdout.strip()
        if not raw:
            logs[log_name] = []
            continue
        try:
            parsed = json.loads(raw)
            logs[log_name] = [parsed] if isinstance(parsed, dict) else parsed
        except json.JSONDecodeError:
            logs[log_name] = {"error": "Failed to parse PowerShell JSON output"}

    return logs


def detect_windows_log_clear_events(lookback_days=90):
    """Event 1102 = Security log cleared. Event 104 = any other log
    cleared (Eventlog-Operational channel). Both are prime anti-forensics
    indicators and are cheap to check for explicitly.
    """
    ps_script = f"""
    $ErrorActionPreference = 'SilentlyContinue'
    $start = (Get-Date).AddDays(-{lookback_days})
    $ev1102 = Get-WinEvent -FilterHashtable @{{LogName='Security'; Id=1102; StartTime=$start}} 2>$null |
        Select-Object TimeCreated, Id, @{{n='LogCleared';e={{'Security'}}}}, @{{n='ClearedBy';e={{$_.Properties[1].Value}}}}
    $ev104 = Get-WinEvent -FilterHashtable @{{LogName='Microsoft-Windows-Eventlog/Operational'; Id=104; StartTime=$start}} 2>$null |
        Select-Object TimeCreated, Id, @{{n='LogCleared';e={{$_.Properties[1].Value}}}}, @{{n='ClearedBy';e={{$_.Properties[0].Value}}}}
    @($ev1102) + @($ev104) | Where-Object {{ $_ -ne $null }} | ConvertTo-Json -Depth 3
    """
    stdout, err = run_command(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script], timeout=60)
    if err or not stdout or not stdout.strip():
        return [], "No log-clear events (1102/104) found in the lookback window, or Security log requires Administrator to query."
    try:
        data = json.loads(stdout.strip())
        events = [data] if isinstance(data, dict) else data
    except json.JSONDecodeError:
        return [], "Could not parse log-clear event JSON."
    return events, None


def collect_windows_archived_evtx():
    """Enumerate rotated/backup .evtx files Windows already created on disk
    (Archive-<Log>-<timestamp>.evtx), which the live collector never looks
    at. These are real historical events already rotated out of the live
    view -- not new deletion recovery, but easy to miss and easy to grab.
    """
    windir = os.environ.get("SystemRoot", "C:\\Windows")
    logs_dir = os.path.join(windir, "System32", "winevt", "Logs")
    if not os.path.isdir(logs_dir):
        return {"error": f"Event log directory not found or inaccessible: {logs_dir}"}
    try:
        archives = [f for f in os.listdir(logs_dir) if f.lower().startswith("archive-") and f.lower().endswith(".evtx")]
    except PermissionError:
        return {"error": "Permission denied listing winevt Logs directory. Run as Administrator."}

    entries = []
    for fname in archives:
        full_path = os.path.join(logs_dir, fname)
        try:
            st = os.stat(full_path)
            entries.append({
                "archive_file": full_path,
                "size_bytes": st.st_size,
                "modified": datetime.fromtimestamp(st.st_mtime).isoformat(),
                "note": "Rotated/backup .evtx not covered by the live Get-WinEvent "
                        "window above. Open directly (e.g. Event Viewer > Open Saved "
                        "Log, or EvtxECmd) for full contents.",
            })
        except OSError as e:
            entries.append({"archive_file": full_path, "error": str(e)})
    return entries


# --------------------------------------------------------------------------
# Linux: live logs (unchanged) + tamper detection + rotated log recovery
# --------------------------------------------------------------------------

def normalize_journal_entry(entry):
    ts_raw = entry.get("__REALTIME_TIMESTAMP")
    if ts_raw:
        try:
            ts = datetime.fromtimestamp(int(ts_raw) / 1_000_000, tz=timezone.utc)
            time_created = ts.isoformat()
        except (ValueError, TypeError, OverflowError):
            time_created = str(ts_raw)
    else:
        time_created = entry.get("_SOURCE_REALTIME_TIMESTAMP", "")

    return {
        "TimeCreated": time_created,
        "Id": entry.get("_PID") or entry.get("SYSLOG_PID") or "",
        "LevelDisplayName": _SYSLOG_LEVEL_MAP.get(str(entry.get("PRIORITY")), "Unknown"),
        "ProviderName": entry.get("SYSLOG_IDENTIFIER") or entry.get("_COMM") or "unknown",
        "Message": entry.get("MESSAGE", ""),
    }


def normalize_log_file_line(line, source_name):
    return {"TimeCreated": "", "Id": "", "LevelDisplayName": "", "ProviderName": source_name, "Message": line}


def collect_linux_logs(max_events=MAX_EVENTS):
    logs = {}
    stdout, err = run_command(["journalctl", "-o", "json", "-n", str(max_events), "--no-pager"], timeout=60)
    if stdout:
        entries = []
        for line in stdout.strip().splitlines():
            try:
                entries.append(normalize_journal_entry(json.loads(line)))
            except json.JSONDecodeError:
                continue
        logs["journalctl"] = entries
    else:
        logs["journalctl"] = {"error": err or "journalctl returned no data (try sudo for full access)."}

    log_files = {
        "syslog": "/var/log/syslog", "auth_log": "/var/log/auth.log",
        "messages": "/var/log/messages", "secure": "/var/log/secure",
        "kern_log": "/var/log/kern.log",
    }
    for name, path in log_files.items():
        if os.path.exists(path):
            try:
                with open(path, "r", errors="replace") as f:
                    lines = f.readlines()[-max_events:]
                logs[name] = [normalize_log_file_line(l.rstrip("\n"), name) for l in lines]
            except PermissionError:
                logs[name] = {"error": f"Permission denied reading {path}. Try sudo."}
            except Exception as e:
                logs[name] = {"error": str(e)}

    return logs


def detect_linux_log_tampering():
    """journald sequence-number gaps / verification failures are the closest
    Linux analogue to Windows' 1102/104 clear events. Also flags an
    unusually empty or freshly-truncated auth.log as a heuristic.
    """
    findings = []

    stdout, err = run_command(["journalctl", "--verify"], timeout=60)
    combined = (stdout or "") + (err or "")
    if combined:
        bad_lines = [l for l in combined.splitlines() if re.search(r"(FAIL|corrupt|bad|invalid)", l, re.I)]
        if bad_lines:
            findings.append({
                "check": "journalctl --verify",
                "result": "possible corruption/tampering detected",
                "details": bad_lines[:25],
            })
        else:
            findings.append({"check": "journalctl --verify", "result": "no corruption reported"})
    else:
        findings.append({"check": "journalctl --verify", "result": "journalctl not available or produced no output"})

    for path in ("/var/log/auth.log", "/var/log/syslog"):
        if os.path.isfile(path):
            try:
                size = os.path.getsize(path)
                mtime = datetime.fromtimestamp(os.path.getmtime(path))
                suspicious = size < 200  # a fresh/near-empty log on an active system is worth flagging
                findings.append({
                    "check": f"size/mtime heuristic: {path}",
                    "size_bytes": size,
                    "modified": mtime.isoformat(),
                    "suspicious_small_size": suspicious,
                })
            except OSError:
                continue

    return findings


def collect_linux_rotated_logs(max_lines_per_file=500):
    """Pull in already-rotated .gz / .N syslog/journal files that the live
    collector skips entirely -- real historical log data still on disk.
    """
    entries = {}
    patterns = [
        "/var/log/syslog.*", "/var/log/auth.log.*",
        "/var/log/messages-*", "/var/log/kern.log.*",
    ]
    for pattern in patterns:
        for path in sorted(glob.glob(pattern)):
            try:
                if path.endswith(".gz"):
                    with gzip.open(path, "rt", errors="replace") as f:
                        lines = f.readlines()[-max_lines_per_file:]
                else:
                    with open(path, "r", errors="replace") as f:
                        lines = f.readlines()[-max_lines_per_file:]
                entries[path] = [normalize_log_file_line(l.rstrip("\n"), os.path.basename(path)) for l in lines]
            except (OSError, PermissionError, EOFError) as e:
                entries[path] = {"error": str(e)}

    # Rotated journal files not yet vacuumed
    journal_dirs = ["/var/log/journal", "/run/log/journal"]
    journal_files = []
    for jd in journal_dirs:
        journal_files.extend(glob.glob(os.path.join(jd, "*", "*.journal")))
    if journal_files:
        entries["_rotated_journal_files_present"] = journal_files

    return entries


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def collect_logs(os_name):
    if os_name == "Windows":
        return {
            "live_logs": collect_windows_logs(),
            "log_clear_events": (lambda r: {"events": r[0], "note": r[1]})(detect_windows_log_clear_events()),
            "archived_evtx_files": collect_windows_archived_evtx(),
        }
    elif os_name == "Linux":
        return {
            "live_logs": collect_linux_logs(),
            "tamper_indicators": detect_linux_log_tampering(),
            "rotated_logs": collect_linux_rotated_logs(),
        }
    else:
        return {"error": f"Unsupported OS for log collection: {os_name}. This module supports Windows and Linux."}


def save_evidence(logs, os_name):
    payload = {
        "generated_at": datetime.now().isoformat(),
        "detected_os": os_name,
        "hostname": platform.node(),
        "max_events_per_source": MAX_EVENTS,
        "logs": logs,
        "notes": (
            "Includes best-effort detection of log-clear events and "
            "recovery of already-rotated/archived log files still on "
            "disk. Logs that were both cleared AND had no rotation "
            "backup are not recoverable by this tool."
        ),
    }
    path, digest = write_json_evidence("system_logs.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def main():
    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print("[*] Collecting system logs, log-clear indicators, and rotated/archived logs...")

    logs = collect_logs(os_name)

    live = logs.get("live_logs", {})
    for source, data in live.items():
        if isinstance(data, dict) and "error" in data:
            print(f"[!] {source}: {data['error']}")
        elif isinstance(data, list):
            print(f"[*] {source}: {len(data)} entries")

    if os_name == "Windows":
        clear = logs.get("log_clear_events", {})
        print(f"[*] Log-clear events (1102/104) found: {len(clear.get('events', []))}")
        if clear.get("note"):
            print(f"[i] {clear['note']}")
        archived = logs.get("archived_evtx_files", [])
        if isinstance(archived, list):
            print(f"[*] Archived .evtx files found: {len(archived)}")
    elif os_name == "Linux":
        for finding in logs.get("tamper_indicators", []):
            print(f"[*] {finding.get('check')}: {finding.get('result')}")
        rotated = logs.get("rotated_logs", {})
        print(f"[*] Rotated log files recovered: {sum(1 for k in rotated if not k.startswith('_'))}")

    fname = save_evidence(logs, os_name)
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
