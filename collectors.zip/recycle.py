"""
recycle.py - Recycle Bin / Trash evidence collector (deleted-but-not-purged
files). Logic unchanged from the working version; now routed through
common.py so its evidence lands in the same per-run case folder and shows
up in the chain-of-custody manifest like every other module.
"""

import os
import sys
import shutil
import struct
import hashlib
import platform
import configparser
import urllib.parse
from datetime import datetime, timedelta

try:
    from ..common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry, get_logger
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence, append_manifest_entry, get_logger

MODULE_NAME = "recycle_bin"


def filetime_to_datetime(ft):
    if not ft or ft <= 0:
        return None
    try:
        return datetime(1601, 1, 1) + timedelta(microseconds=ft / 10)
    except (OverflowError, OSError):
        return None


def parse_index_file(path):
    with open(path, "rb") as f:
        data = f.read()
    if len(data) < 24:
        return {"error": "File too short to be a valid $I record"}

    version = struct.unpack("<q", data[0:8])[0]
    file_size = struct.unpack("<q", data[8:16])[0]
    deleted_raw = struct.unpack("<q", data[16:24])[0]
    deleted_time = filetime_to_datetime(deleted_raw)

    try:
        if version == 1:
            original_name = data[24:].decode("utf-16-le", errors="replace").split("\x00")[0]
        else:
            name_len = struct.unpack("<i", data[24:28])[0]
            original_name = data[28:28 + name_len * 2].decode("utf-16-le", errors="replace").rstrip("\x00")
    except Exception as e:
        return {
            "version": version, "file_size": file_size,
            "deleted_time": deleted_time.isoformat() if deleted_time else None,
            "original_name": None, "parse_warning": f"Could not decode file name: {e}",
        }

    return {
        "version": version, "file_size": file_size,
        "deleted_time": deleted_time.isoformat() if deleted_time else None,
        "original_name": original_name,
    }


def collect_windows_recycle_bin():
    entries = []
    system_drive = os.environ.get("SystemDrive", "C:")
    root = f"{system_drive}\\$Recycle.Bin"
    if not os.path.isdir(root):
        return {"error": f"Recycle Bin root not found or inaccessible: {root}"}
    try:
        sid_dirs = os.listdir(root)
    except PermissionError:
        return {"error": f"Permission denied listing {root}. Run as Administrator."}

    for sid in sid_dirs:
        sid_path = os.path.join(root, sid)
        if not os.path.isdir(sid_path):
            continue
        try:
            files = os.listdir(sid_path)
        except PermissionError:
            entries.append({"sid": sid, "error": "Permission denied (likely another user's bin). Run as Administrator."})
            continue

        for fname in files:
            if not fname.startswith("$I"):
                continue
            info_path = os.path.join(sid_path, fname)
            data_path = os.path.join(sid_path, "$R" + fname[2:])
            try:
                parsed = parse_index_file(info_path)
            except (PermissionError, FileNotFoundError) as e:
                parsed = {"error": str(e)}
            entries.append({
                "sid": sid, "index_file": info_path,
                "data_file": data_path if os.path.exists(data_path) else None,
                "data_file_recoverable": os.path.exists(data_path),
                **parsed,
            })
    return entries


def parse_trashinfo(path):
    config = configparser.ConfigParser(interpolation=None)
    try:
        config.read(path, encoding="utf-8")
        section = config["Trash Info"]
        return {
            "original_path": urllib.parse.unquote(section.get("Path", "")),
            "deletion_date": section.get("DeletionDate", None),
        }
    except (configparser.Error, KeyError) as e:
        return {"error": f"Could not parse trashinfo: {e}"}


def collect_trash_dir(trash_root, label):
    entries = []
    info_dir = os.path.join(trash_root, "info")
    files_dir = os.path.join(trash_root, "files")
    if not os.path.isdir(info_dir):
        return entries
    try:
        info_files = os.listdir(info_dir)
    except PermissionError:
        return [{"trash_root": trash_root, "error": "Permission denied"}]

    for fname in info_files:
        if not fname.endswith(".trashinfo"):
            continue
        base_name = fname[: -len(".trashinfo")]
        parsed = parse_trashinfo(os.path.join(info_dir, fname))
        data_path = os.path.join(files_dir, base_name)
        exists = os.path.exists(data_path)
        size = None
        if exists:
            try:
                size = os.path.getsize(data_path) if os.path.isfile(data_path) else None
            except OSError:
                size = None
        entries.append({
            "trash_source": label, "info_file": os.path.join(info_dir, fname),
            "data_file": data_path if exists else None, "data_file_recoverable": exists,
            "file_size": size, **parsed,
        })
    return entries


def collect_linux_trash():
    entries = []
    xdg_data_home = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
    entries.extend(collect_trash_dir(os.path.join(xdg_data_home, "Trash"), "home"))

    uid = os.getuid() if hasattr(os, "getuid") else None
    for mount_base in ("/media", "/mnt", "/run/media"):
        if not os.path.isdir(mount_base):
            continue
        try:
            for entry in os.listdir(mount_base):
                candidate_base = os.path.join(mount_base, entry)
                if not os.path.isdir(candidate_base):
                    continue
                subs = [candidate_base] + [
                    os.path.join(candidate_base, s) for s in os.listdir(candidate_base)
                    if os.path.isdir(os.path.join(candidate_base, s))
                ]
                for sub in subs:
                    trash_dir = os.path.join(sub, f".Trash-{uid}") if uid is not None else None
                    if trash_dir and os.path.isdir(trash_dir):
                        entries.extend(collect_trash_dir(trash_dir, f"volume:{sub}"))
        except (PermissionError, FileNotFoundError):
            continue
    return entries


def collect_recycle_bin(os_name):
    if os_name == "Windows":
        return collect_windows_recycle_bin()
    elif os_name == "Linux":
        return collect_linux_trash()
    return {"error": f"Unsupported OS for recycle bin collection: {os_name}. This module supports Windows and Linux."}


def sha256_file(path):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def unique_destination(recover_dir, desired_name):
    dest = os.path.join(recover_dir, desired_name)
    if not os.path.exists(dest):
        return dest
    base, ext = os.path.splitext(desired_name)
    counter = 1
    while True:
        candidate = os.path.join(recover_dir, f"{base}_{counter}{ext}")
        if not os.path.exists(candidate):
            return candidate
        counter += 1


def recover_files(entries):
    if isinstance(entries, dict):
        return entries, 0

    ensure_evidence_dir()
    recover_dir = os.path.join(EVIDENCE_DIR, "recover")
    os.makedirs(recover_dir, exist_ok=True)
    recovered_count = 0

    for entry in entries:
        data_path = entry.get("data_file")
        if not data_path or not entry.get("data_file_recoverable"):
            continue
        original_name = entry.get("original_name")
        desired_name = os.path.basename(original_name) if original_name else os.path.basename(data_path)
        sid_or_source = entry.get("sid") or entry.get("trash_source") or "src"
        safe_prefix = "".join(c if c.isalnum() else "_" for c in str(sid_or_source))[:16]
        desired_name = f"{safe_prefix}__{desired_name}" if desired_name else f"{safe_prefix}__recovered"
        dest_path = unique_destination(recover_dir, desired_name)

        try:
            if os.path.isdir(data_path):
                shutil.copytree(data_path, dest_path, symlinks=True)
                entry["recovered_path"] = dest_path
                entry["recovered_type"] = "directory"
                entry["recovered_file_count"] = sum(len(f) for _, _, f in os.walk(dest_path))
                recovered_count += 1
            elif os.path.isfile(data_path):
                shutil.copy2(data_path, dest_path)
                entry["recovered_path"] = dest_path
                entry["recovered_type"] = "file"
                entry["recovered_sha256"] = sha256_file(dest_path)
                recovered_count += 1
            else:
                entry["recover_error"] = "Data path exists but is neither a file nor a directory (broken link?)"
        except (OSError, shutil.Error) as e:
            entry["recover_error"] = str(e)

    return entries, recovered_count


def save_evidence(entries, os_name):
    total = 0 if (isinstance(entries, dict) and "error" in entries) else len(entries)
    payload = {
        "generated_at": datetime.now().isoformat(), "detected_os": os_name,
        "hostname": platform.node(), "total_deleted_items": total, "items": entries,
    }
    path, digest = write_json_evidence("recycle_bin.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def main():
    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print("[*] Collecting recycle bin / trash evidence...")

    entries = collect_recycle_bin(os_name)

    if isinstance(entries, dict) and "error" in entries:
        print(f"[!] {entries['error']}")
    else:
        recoverable = sum(1 for e in entries if e.get("data_file_recoverable"))
        errors = sum(1 for e in entries if "error" in e)
        print(f"[*] Found {len(entries)} deleted item record(s).")
        print(f"[*] {recoverable} still have recoverable data on disk.")
        if errors:
            print(f"[!] {errors} record(s) had errors (see JSON for details).")
        print("[*] Recovering files and folders into evidence 'recover' folder...")
        entries, recovered_count = recover_files(entries)
        print(f"[+] Recovered {recovered_count} item(s).")

    fname = save_evidence(entries, os_name)
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
