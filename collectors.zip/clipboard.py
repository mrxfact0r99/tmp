"""
clipboard.py - Clipboard evidence collector.

UPGRADE NOTES (why this file changed):
The old version only ever captured a single, one-shot snapshot of whatever
was on the clipboard *right now* -- so the evidence file only ever showed
"the last thing copied". The OS clipboard itself is a single-slot buffer;
there is no OS-level "give me everything that has ever been copied" API on
stock Windows/Linux/macOS. To actually produce a *history* of clipboard
content instead of one item, this module now pulls from every real source
that can contain more than one entry:

  1. Live snapshot (kept, for compatibility).
  2. Native OS clipboard *history* stores, where the OS/DE keeps one:
       - Windows 10/11 "Clipboard History" (Win+V), via the WinRT API.
       - Linux clipboard managers: Klipper (KDE), CopyQ, GPaste (GNOME).
       - macOS has no built-in history; this is reported honestly rather
         than faked.
  3. A background monitor thread (ClipboardMonitor) that polls the live
     clipboard at short intervals and appends every *new, distinct* value
     it sees to a running history, with timestamps and content hashes for
     dedup. This is how you get "every item that was on the clipboard"
     during a run, without blocking/interrupting the rest of the report:
     forensics.py starts this monitor before running the other collectors
     and stops it right before this module writes its evidence file.

Honesty note on "deleted clipboard data": once a value is overwritten in
volatile clipboard memory and was never captured by a history store or
this monitor, it is gone -- there is no reliable forensic recovery path
for it from userland (only a live RAM/pagefile forensic capture with a
tool like Volatility could ever find remnants, and even that is not
guaranteed). This module does not claim to recover it; it maximizes what
*can* legitimately be captured going forward and from any history the OS
already kept.
"""

import os
import sys
import json
import time
import platform
import subprocess
import threading
from pathlib import Path
from datetime import datetime

try:
    from ..common import (
        EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence,
        append_manifest_entry, sha256_bytes, get_logger, run_command,
    )
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import (
        EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence,
        append_manifest_entry, sha256_bytes, get_logger, run_command,
    )

MODULE_NAME = "clipboard"


# --------------------------------------------------------------------------
# Live snapshot readers (unchanged mechanics, kept for the "current value")
# --------------------------------------------------------------------------

def read_via_pyperclip():
    try:
        import pyperclip
        return pyperclip.paste(), None
    except ImportError:
        return None, "pyperclip not installed"
    except Exception as e:
        return None, str(e)


def read_windows_native():
    try:
        import ctypes
        from ctypes import wintypes

        CF_UNICODETEXT = 13
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        user32.OpenClipboard.argtypes = [wintypes.HWND]
        user32.OpenClipboard.restype = wintypes.BOOL
        user32.GetClipboardData.argtypes = [wintypes.UINT]
        user32.GetClipboardData.restype = wintypes.HANDLE
        user32.CloseClipboard.argtypes = []
        user32.CloseClipboard.restype = wintypes.BOOL
        kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        kernel32.GlobalUnlock.restype = wintypes.BOOL

        if not user32.OpenClipboard(None):
            return None, "Could not open clipboard (may be in use by another app)."
        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return None, "Clipboard is empty or does not contain text."
            pointer = kernel32.GlobalLock(handle)
            if not pointer:
                return None, "Could not lock clipboard memory."
            try:
                return ctypes.wstring_at(pointer), None
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()
    except Exception as e:
        return None, str(e)


def read_linux_native():
    for cmd in (
        ["xclip", "-selection", "clipboard", "-o"],
        ["xsel", "--clipboard", "--output"],
        ["wl-paste"],
    ):
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                return result.stdout, None
        except FileNotFoundError:
            continue
        except Exception as e:
            return None, str(e)
    return None, (
        "No clipboard tool found. Install one: "
        "'sudo apt install xclip' (X11) or 'sudo apt install wl-clipboard' (Wayland)."
    )


def read_macos_native():
    try:
        result = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return result.stdout, None
        return None, result.stderr.strip() or "pbpaste failed."
    except FileNotFoundError:
        return None, "pbpaste not found (unexpected on macOS)."
    except Exception as e:
        return None, str(e)


def get_clipboard_content(os_name):
    content, err = read_via_pyperclip()
    if content is not None:
        return content, "pyperclip", None

    if os_name == "Windows":
        content, native_err = read_windows_native()
        source = "windows_ctypes"
    elif os_name == "Linux":
        content, native_err = read_linux_native()
        source = "linux_native_tool"
    elif os_name == "macOS":
        content, native_err = read_macos_native()
        source = "pbpaste"
    else:
        content, native_err = None, f"Unsupported OS: {os_name}"
        source = None

    return content, source, (native_err or err)


# --------------------------------------------------------------------------
# Native OS/DE clipboard *history* stores (more than one item)
# --------------------------------------------------------------------------

def collect_windows_clipboard_history():
    """Query the Windows 10/11 built-in Clipboard History (Win+V) via the
    WinRT Clipboard API. Requires the feature to be turned on in Windows
    Settings > System > Clipboard; if it's off, Windows itself keeps no
    history to retrieve, which this reports rather than failing silently.
    """
    ps_script = r"""
$ErrorActionPreference = 'Stop'
try {
    [Windows.ApplicationModel.DataTransfer.Clipboard,Windows.ApplicationModel.DataTransfer,ContentType=WindowsRuntime] | Out-Null
    [Windows.Foundation.IAsyncOperation`1[Windows.ApplicationModel.DataTransfer.ClipboardHistoryItemsResult]] | Out-Null
    $op = [Windows.ApplicationModel.DataTransfer.Clipboard]::GetHistoryItemsAsync()
    while ($op.Status -eq 'Started') { Start-Sleep -Milliseconds 50 }
    $result = $op.GetResults()
    $out = @()
    foreach ($item in $result.Items) {
        $textOp = $item.Content.GetTextAsync()
        while ($textOp.Status -eq 'Started') { Start-Sleep -Milliseconds 20 }
        try { $text = $textOp.GetResults() } catch { $text = $null }
        $out += [PSCustomObject]@{
            Timestamp = $item.Timestamp.ToString("o")
            Id        = $item.Id
            Text      = $text
        }
    }
    $out | ConvertTo-Json -Depth 4
} catch {
    Write-Output "__ERROR__:$($_.Exception.Message)"
}
"""
    stdout, err = run_command(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script], timeout=30)
    if err or stdout is None:
        return [], (err or "PowerShell clipboard history query failed.")

    raw = stdout.strip()
    if raw.startswith("__ERROR__"):
        return [], (
            "Could not read Windows Clipboard History API "
            f"({raw.split(':', 1)[-1].strip()}). This usually means Clipboard "
            "History is turned off (Settings > System > Clipboard > "
            "Clipboard history) or there is no history yet."
        )
    if not raw:
        return [], "Windows Clipboard History returned no items (feature may be off, or history is empty)."

    try:
        data = json.loads(raw)
        if isinstance(data, dict):
            data = [data]
    except json.JSONDecodeError:
        return [], "Could not parse Clipboard History JSON output."

    entries = []
    for item in data:
        entries.append({
            "source": "windows_clipboard_history_api",
            "timestamp": item.get("Timestamp"),
            "history_id": item.get("Id"),
            "content": item.get("Text"),
            "content_sha256": sha256_bytes(item.get("Text")) if item.get("Text") else None,
        })
    return entries, None


def _try_read_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return None


def collect_linux_clipboard_manager_history():
    """Best-effort read of history kept by common Linux clipboard managers.
    Only reads files that already exist -- never installs/enables anything.
    """
    home = os.path.expanduser("~")
    entries = []
    notes = []

    # --- Klipper (KDE) ---
    klipper_path = os.path.join(home, ".local", "share", "klipper", "history2.lst")
    if not os.path.isfile(klipper_path):
        klipper_path = os.path.join(home, ".kde", "share", "apps", "klipper", "history2.lst")
    if os.path.isfile(klipper_path):
        raw = _try_read_file(klipper_path)
        if raw:
            for line in raw.splitlines():
                line = line.strip()
                if line and not line.startswith("<!") and "<clipboard" not in line.lower():
                    entries.append({
                        "source": "klipper_history",
                        "history_file": klipper_path,
                        "content_raw_line": line,
                    })
        notes.append(f"Read Klipper history: {klipper_path}")

    # --- CopyQ ---
    copyq_dirs = [
        os.path.join(home, ".config", "copyq"),
        os.path.join(home, ".local", "share", "copyq"),
    ]
    for d in copyq_dirs:
        if not os.path.isdir(d):
            continue
        for fname in os.listdir(d):
            if fname.endswith(".dat") or "copyq" in fname.lower():
                notes.append(
                    f"CopyQ data file found at {os.path.join(d, fname)} "
                    "(binary tab format -- export via 'copyq eval' for full text)."
                )
        # CopyQ exposes its history over its own CLI/D-Bus interface too:
        stdout, err = run_command(["copyq", "eval", "for(i=0;i<size();i++){print(str(read(i))+chr(0))}"], timeout=10)
        if stdout:
            for item in stdout.split("\x00"):
                if item.strip():
                    entries.append({"source": "copyq_cli", "content": item})
        break

    # --- GPaste (GNOME) ---
    stdout, err = run_command(["gpaste-client", "history"], timeout=10)
    if stdout:
        for line in stdout.splitlines():
            line = line.strip()
            if line:
                entries.append({"source": "gpaste_history", "content_raw_line": line})
    else:
        gpaste_cache = os.path.join(home, ".cache", "gpaste", "history.xml")
        if os.path.isfile(gpaste_cache):
            notes.append(f"GPaste cache present at {gpaste_cache} but gpaste-client unavailable to query it live.")

    if not entries and not notes:
        notes.append(
            "No known clipboard manager (Klipper/CopyQ/GPaste) history found. "
            "Without a clipboard manager, the OS clipboard is single-slot and "
            "only the live monitor below can build a history going forward."
        )

    return entries, notes


def collect_native_clipboard_history(os_name):
    if os_name == "Windows":
        entries, err = collect_windows_clipboard_history()
        return entries, ([err] if err else [])
    elif os_name == "Linux":
        return collect_linux_clipboard_manager_history()
    elif os_name == "macOS":
        return [], [
            "macOS does not ship a built-in clipboard history API. If a "
            "third-party manager (e.g. Maccy, Paste, Alfred) is installed, "
            "its own history store would need to be targeted specifically."
        ]
    return [], [f"Unsupported OS: {os_name}"]


# --------------------------------------------------------------------------
# Background live monitor -- builds real history going forward, and runs
# concurrently with the rest of the report so nothing is blocked on it.
# --------------------------------------------------------------------------

class ClipboardMonitor:
    """Polls the live clipboard on a background thread and records every
    distinct value seen. Designed to be started before other collectors
    run and stopped just before this module writes its evidence, so the
    report is not interrupted/delayed waiting on clipboard activity.
    """

    def __init__(self, os_name, poll_interval=1.0):
        self.os_name = os_name
        self.poll_interval = poll_interval
        self._history = []
        self._seen_hashes = set()
        self._stop_event = threading.Event()
        self._thread = None
        self._lock = threading.Lock()

    def _poll_once(self):
        content, source, err = get_clipboard_content(self.os_name)
        if content is None:
            return
        h = sha256_bytes(content)
        with self._lock:
            if h in self._seen_hashes:
                return
            self._seen_hashes.add(h)
            self._history.append({
                "source": f"live_monitor:{source}",
                "captured_at": datetime.now().isoformat(),
                "content": content,
                "content_length_chars": len(content),
                "content_sha256": h,
            })

    def _run(self):
        while not self._stop_event.is_set():
            try:
                self._poll_once()
            except Exception:
                pass
            self._stop_event.wait(self.poll_interval)

    def start(self):
        if self._thread is not None:
            return
        self._poll_once()  # capture whatever is already there immediately
        self._thread = threading.Thread(target=self._run, daemon=True, name="clipboard-monitor")
        self._thread.start()

    def stop(self, timeout=5):
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)

    def get_history(self):
        with self._lock:
            return list(self._history)


# A module-level monitor so forensics.py (the orchestrator) can start it
# early and this module can pick up whatever it collected when it runs.
_shared_monitor = None


def start_background_monitor(os_name, poll_interval=1.0):
    global _shared_monitor
    if _shared_monitor is None:
        _shared_monitor = ClipboardMonitor(os_name, poll_interval=poll_interval)
        _shared_monitor.start()
    return _shared_monitor


def stop_background_monitor():
    global _shared_monitor
    if _shared_monitor is not None:
        _shared_monitor.stop()
        return _shared_monitor.get_history()
    return []


# --------------------------------------------------------------------------
# Evidence assembly
# --------------------------------------------------------------------------

def save_evidence(payload):
    path, digest = write_json_evidence("clipboard_evidence.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def collect(monitor_seconds=0):
    """Full collection: live snapshot + native history stores + (optionally)
    a self-contained monitor window if this module is run standalone rather
    than orchestrated by forensics.py.
    """
    os_name = detect_os()
    logger = get_logger()

    logger.info("Reading live clipboard snapshot...")
    content, source, error = get_clipboard_content(os_name)

    logger.info("Reading native clipboard history stores...")
    native_history, native_notes = collect_native_clipboard_history(os_name)

    monitor_history = []
    if _shared_monitor is not None:
        # Orchestrated run: use whatever the shared monitor already gathered.
        monitor_history = stop_background_monitor()
    elif monitor_seconds > 0:
        # Standalone run with an explicit monitor window requested.
        mon = ClipboardMonitor(os_name)
        mon.start()
        time.sleep(monitor_seconds)
        monitor_history = mon.stop() or mon.get_history()

    all_entries = []
    if content is not None:
        all_entries.append({
            "source": f"live_snapshot:{source}",
            "captured_at": datetime.now().isoformat(),
            "content": content,
            "content_length_chars": len(content),
            "content_sha256": sha256_bytes(content),
        })
    all_entries.extend(native_history)
    all_entries.extend(monitor_history)

    # Dedup across all sources by content hash, keep earliest-known timestamp.
    deduped = {}
    for e in all_entries:
        key = e.get("content_sha256") or e.get("content") or e.get("content_raw_line")
        if key is None:
            continue
        if key not in deduped:
            deduped[key] = e

    payload = {
        "generated_at": datetime.now().isoformat(),
        "detected_os": os_name,
        "hostname": platform.node(),
        "live_snapshot": {
            "read_method": source,
            "content": content,
            "content_length_chars": len(content) if content else 0,
            "error": error if content is None else None,
        },
        "native_history_notes": native_notes,
        "total_distinct_items_recovered": len(deduped),
        "clipboard_history": list(deduped.values()),
        "limitations": (
            "Only clipboard content captured by a native OS/DE history "
            "store, or observed while the live monitor was running, can "
            "appear here. Values that were copied, overwritten, and never "
            "seen by either mechanism are not recoverable from userland; "
            "that would require a live memory/pagefile forensic capture."
        ),
    }
    return payload


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Clipboard evidence collector")
    parser.add_argument("--monitor-seconds", type=int, default=0,
                         help="When run standalone (not via forensics.py), watch the "
                              "clipboard for this many seconds before writing evidence.")
    args = parser.parse_args()

    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print("[*] Collecting clipboard evidence (live value + native history stores)...")
    if args.monitor_seconds:
        print(f"[*] Also monitoring clipboard for {args.monitor_seconds}s to catch multiple items...")

    payload = collect(monitor_seconds=args.monitor_seconds)

    print(f"[*] Distinct clipboard items recovered: {payload['total_distinct_items_recovered']}")
    if payload["live_snapshot"]["content"] is not None:
        c = payload["live_snapshot"]["content"]
        preview = c if len(c) <= 100 else c[:100] + "..."
        print(f"[*] Current clipboard preview: {preview!r}")
    for note in payload["native_history_notes"]:
        print(f"[i] {note}")

    fname = save_evidence(payload)
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
