"""
history.py - Browser history evidence collector.

UPGRADE NOTES:
The old version only queried the *live* rows in each browser's history
database (SELECT ... FROM urls / moz_places). SQLite does not truly erase
deleted rows immediately -- when a row is deleted, SQLite marks its page
space as free but the old bytes often remain on disk until that space is
reused, and rows can also survive in -wal / -shm side files and rotated
"Archived History" files. This version adds a best-effort *carving* pass
over those raw bytes to recover URLs that no longer show up in the live
query, in addition to the live query itself (which still runs first and
is authoritative for anything not deleted).

Honesty note: carving free-page bytes recovers *fragments* (URLs, and
where possible titles) -- it cannot always reconstruct full context (exact
visit time, visit count) the way a live row can, because that metadata may
have been overwritten. Every carved record is labeled clearly as
"recovered_deleted" and kept separate from the live "history" list so nothing
is silently presented as more certain than it is.
"""

import os
import re
import sys
import json
import glob
import shutil
import sqlite3
import platform
import argparse
import tempfile
from datetime import datetime, timedelta

try:
    from ..common import (
        EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence,
        append_manifest_entry, get_logger,
    )
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from common import (
        EVIDENCE_DIR, detect_os, ensure_evidence_dir, write_json_evidence,
        append_manifest_entry, get_logger,
    )

MODULE_NAME = "browser_history"

URL_CARVE_RE = re.compile(rb"https?://[\x21-\x7e]{4,2048}")


# --------------------------------------------------------------------------
# Profile discovery
# --------------------------------------------------------------------------

def get_chromium_paths(os_name):
    home = os.path.expanduser("~")
    candidates = {}

    if os_name == "Windows":
        base = os.path.join(home, "AppData", "Local")
        chromium_dirs = {
            "Chrome": os.path.join(base, "Google", "Chrome", "User Data"),
            "Edge": os.path.join(base, "Microsoft", "Edge", "User Data"),
            "Brave": os.path.join(base, "BraveSoftware", "Brave-Browser", "User Data"),
        }
    elif os_name == "Linux":
        chromium_dirs = {
            "Chrome": os.path.join(home, ".config", "google-chrome"),
            "Chromium": os.path.join(home, ".config", "chromium"),
            "Brave": os.path.join(home, ".config", "BraveSoftware", "Brave-Browser"),
        }
    elif os_name == "macOS":
        base = os.path.join(home, "Library", "Application Support")
        chromium_dirs = {
            "Chrome": os.path.join(base, "Google", "Chrome"),
            "Edge": os.path.join(base, "Microsoft Edge"),
            "Brave": os.path.join(base, "BraveSoftware", "Brave-Browser"),
        }
    else:
        chromium_dirs = {}

    for label, root in chromium_dirs.items():
        if not os.path.isdir(root):
            continue
        # Live + rotated "Archived History" (Chromium periodically moves
        # older rows here -- still real history, just not in the main file).
        history_files = sorted(set(
            glob.glob(os.path.join(root, "*", "History"))
            + glob.glob(os.path.join(root, "Default", "History"))
            + glob.glob(os.path.join(root, "*", "Archived History"))
            + glob.glob(os.path.join(root, "Default", "Archived History"))
        ))
        if history_files:
            candidates[label] = history_files

    return candidates


def get_firefox_paths(os_name):
    home = os.path.expanduser("~")
    if os_name == "Windows":
        root = os.path.join(home, "AppData", "Roaming", "Mozilla", "Firefox", "Profiles")
    elif os_name == "Linux":
        root = os.path.join(home, ".mozilla", "firefox")
    elif os_name == "macOS":
        root = os.path.join(home, "Library", "Application Support", "Firefox", "Profiles")
    else:
        return []

    if not os.path.isdir(root):
        return []
    return sorted(glob.glob(os.path.join(root, "*", "places.sqlite")))


# --------------------------------------------------------------------------
# Live queries (unchanged approach)
# --------------------------------------------------------------------------

def read_sqlite_copy(db_path, query, columns):
    tmp_dir = tempfile.mkdtemp(prefix="browser_evidence_")
    tmp_path = os.path.join(tmp_dir, "copy.sqlite")
    rows_out = []
    error = None
    copied_side_files = []
    try:
        shutil.copy2(db_path, tmp_path)
        for ext in ("-wal", "-shm"):
            side_file = db_path + ext
            if os.path.exists(side_file):
                try:
                    shutil.copy2(side_file, tmp_path + ext)
                    copied_side_files.append(side_file)
                except Exception:
                    pass

        conn = sqlite3.connect(f"file:{tmp_path}?immutable=0", uri=True)
        cur = conn.cursor()
        cur.execute(query)
        for row in cur.fetchall():
            rows_out.append(dict(zip(columns, row)))
        conn.close()
    except Exception as e:
        error = str(e)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    return rows_out, error, copied_side_files


def chrome_time_to_iso(chrome_us):
    try:
        epoch_start = datetime(1601, 1, 1)
        return (epoch_start + timedelta(microseconds=chrome_us)).isoformat()
    except Exception:
        return None


def firefox_time_to_iso(ff_us):
    if ff_us is None:
        return None
    try:
        return datetime.fromtimestamp(ff_us / 1_000_000).isoformat()
    except (OverflowError, OSError, ValueError, TypeError):
        return None


def collect_chromium_history(path, limit):
    query = f"""
        SELECT url, title, visit_count, last_visit_time
        FROM urls
        ORDER BY last_visit_time DESC
        LIMIT {int(limit)}
    """
    rows, error, _ = read_sqlite_copy(path, query, ["url", "title", "visit_count", "last_visit_time"])
    for r in rows:
        r["last_visit_time_iso"] = chrome_time_to_iso(r["last_visit_time"])
    return rows, error


def collect_chromium_search_terms(path, limit):
    query = f"""
        SELECT kst.term, u.url, u.last_visit_time
        FROM keyword_search_terms kst
        JOIN urls u ON kst.url_id = u.id
        ORDER BY u.last_visit_time DESC
        LIMIT {int(limit)}
    """
    rows, error, _ = read_sqlite_copy(path, query, ["search_term", "url", "last_visit_time"])
    for r in rows:
        r["last_visit_time_iso"] = chrome_time_to_iso(r["last_visit_time"])
    return rows, error


def collect_firefox_history(path, limit):
    query = f"""
        SELECT url, title, visit_count, last_visit_date
        FROM moz_places
        WHERE last_visit_date IS NOT NULL
        ORDER BY last_visit_date DESC
        LIMIT {int(limit)}
    """
    rows, error, _ = read_sqlite_copy(path, query, ["url", "title", "visit_count", "last_visit_date"])
    for r in rows:
        r["last_visit_time_iso"] = firefox_time_to_iso(r["last_visit_date"])
    return rows, error


# --------------------------------------------------------------------------
# Deleted-record carving (best effort)
# --------------------------------------------------------------------------

def carve_urls_from_file(path):
    """Scan raw bytes of a SQLite file (and its -wal side file, if present)
    for URL-shaped byte strings. This catches URLs sitting in freed pages
    (deleted rows) and in WAL frames not yet checkpointed into the main
    live query. Returns a de-duplicated list of carved URL strings.
    """
    found = set()
    for candidate in (path, path + "-wal"):
        if not os.path.isfile(candidate):
            continue
        try:
            with open(candidate, "rb") as f:
                data = f.read()
        except OSError:
            continue
        for m in URL_CARVE_RE.finditer(data):
            try:
                url = m.group(0).decode("utf-8", errors="ignore")
            except Exception:
                continue
            # Trim obvious trailing garbage carried in from adjacent field bytes.
            url = url.rstrip("\\\"'<>")
            if 8 < len(url) < 2048:
                found.add(url)
    return found


def recover_deleted_urls(db_path, live_rows, url_key="url"):
    """Diff carved URLs against what the live query already returned, so
    the 'recovered_deleted' list only contains URLs not visible via the
    live table (i.e. plausibly deleted, or at least not currently indexed).
    """
    live_urls = {r.get(url_key) for r in live_rows if r.get(url_key)}
    carved = carve_urls_from_file(db_path)
    recovered = sorted(carved - live_urls)
    return [
        {
            "url": u,
            "recovery_method": "raw_byte_carving_freepages_and_wal",
            "confidence": "low-medium: URL string recovered from unallocated/"
                           "WAL space; visit time/count could not be reliably "
                           "reconstructed and are not shown.",
        }
        for u in recovered
    ]


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def save_evidence(payload):
    path, digest = write_json_evidence("browser_artifacts.json", payload)
    append_manifest_entry(MODULE_NAME, path, digest)
    return path


def collect(limit=1000, carve_deleted=True):
    os_name = detect_os()
    logger = get_logger()

    result = {
        "generated_at": datetime.now().isoformat(),
        "detected_os": os_name,
        "hostname": platform.node(),
        "browsers": {},
        "deleted_recovery_enabled": carve_deleted,
    }

    chromium_paths = get_chromium_paths(os_name)
    for label, history_files in chromium_paths.items():
        for hist_path in history_files:
            profile_name = os.path.basename(os.path.dirname(hist_path))
            is_archive = os.path.basename(hist_path) == "Archived History"
            key = f"{label} ({profile_name}){' [archived]' if is_archive else ''}"
            logger.info(f"Reading {key} from {hist_path}")

            history_rows, hist_err = collect_chromium_history(hist_path, limit)
            search_rows, search_err = collect_chromium_search_terms(hist_path, limit)

            recovered = []
            if carve_deleted and not hist_err:
                try:
                    recovered = recover_deleted_urls(hist_path, history_rows, url_key="url")
                except Exception as e:
                    logger.exception(f"Carving failed for {hist_path}")

            result["browsers"][key] = {
                "source_path": hist_path,
                "history_count": len(history_rows),
                "history": history_rows,
                "history_error": hist_err,
                "search_terms_count": len(search_rows),
                "search_terms": search_rows,
                "search_terms_error": search_err,
                "deleted_urls_recovered_count": len(recovered),
                "deleted_urls_recovered": recovered,
            }

    ff_paths = get_firefox_paths(os_name)
    for places_path in ff_paths:
        profile_name = os.path.basename(os.path.dirname(places_path))
        key = f"Firefox ({profile_name})"
        logger.info(f"Reading {key} from {places_path}")

        history_rows, hist_err = collect_firefox_history(places_path, limit)

        recovered = []
        if carve_deleted and not hist_err:
            try:
                recovered = recover_deleted_urls(places_path, history_rows, url_key="url")
            except Exception:
                logger.exception(f"Carving failed for {places_path}")

        result["browsers"][key] = {
            "source_path": places_path,
            "history_count": len(history_rows),
            "history": history_rows,
            "history_error": hist_err,
            "deleted_urls_recovered_count": len(recovered),
            "deleted_urls_recovered": recovered,
        }

    if not result["browsers"]:
        result["note"] = "No known browser profiles found on this system for the current user."

    return result


def main():
    parser = argparse.ArgumentParser(description="Acquire local browser history/search artifacts, including best-effort deleted-URL recovery.")
    parser.add_argument("--limit", type=int, default=1000,
                         help="Max rows to pull per browser profile (default: 1000)")
    parser.add_argument("--no-carve", action="store_true",
                         help="Skip the deleted-URL carving pass (live history only).")
    args = parser.parse_args()

    os_name = detect_os()
    print(f"[*] Detected OS: {os_name}")
    print("[*] Locating browser profiles...")

    result = collect(limit=args.limit, carve_deleted=not args.no_carve)

    total = sum(v.get("history_count", 0) for v in result["browsers"].values())
    total_recovered = sum(v.get("deleted_urls_recovered_count", 0) for v in result["browsers"].values())

    fname = save_evidence(result)
    print(f"[*] Total live history entries collected: {total}")
    print(f"[*] Total deleted URLs recovered (carved): {total_recovered}")
    if not result["browsers"]:
        print("[i] No browser profiles found.")
    print(f"[+] Evidence saved to: {fname}")


if __name__ == "__main__":
    main()
